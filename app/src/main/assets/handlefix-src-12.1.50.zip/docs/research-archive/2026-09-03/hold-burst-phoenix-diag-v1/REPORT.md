# Phoenix-0.3.0 快门长按原生高速连拍窄诊断包执行报告

日期：2026-08-30
基线仓库：`C:\Users\Ryan\Documents\Codex\2026-08-01\new-chat\work\ui_rewrite`
诊断目标：`com.android.camera` / Phoenix-0.3.0 / `versionCode=760000300` / 普通拍照 `moduleId=163`
本报告状态：独立、未提交；本轮已停止在诊断包阶段，没有进入功能实现阶段。

## 1. 基线与范围

执行前只读核对结果：

- 当前分支：`master`。
- `HEAD`：`c88f0e847fe11fa49a05dbaa54df8421ea38a92e`。
- `origin/master`：与 `HEAD` 一致。
- 工作树原有的 `STATUS.md`、`analysis/`、`app/src/test-assets/`、`diagnostics/`、`outputs/` 未删除、未清理、未整体加入 Git。
- 未执行 `git clean`、`git reset --hard`、`git checkout --`、`git add .`、提交、推送、ADB 安装或设备重启。

本轮只新增观察型探针，不新增设置项，不实现 `F_HOLD_BURST`，不消费或重写快门事件，不调用拍照/连拍入口，也未修改 `DualStyleCaptureHooks.java` 的功能语义。

## 2. 修改文件

### `app/build.gradle.kts`

增加项目属性 `holdBurstDiag` 的布尔解析，默认值为 `false`。只有显式使用 `-PholdBurstDiag=true` 时：

- `versionName` 变为 `12.0.98-HOLD-BURST-PHOENIX-DIAG-TEST`；
- `versionCode` 变为 `1301`；
- `BuildConfig.HOLD_BURST_DIAGNOSTIC` 为 `true`。

无参数或传入非 `true` 值时仍为 `12.0.97`、`1300`、`false`。同时显式开启 AGP 所需的 `buildFeatures.buildConfig = true`，仅用于生成该项目属性常量。

### `app/src/main/java/com/handlefix/HandleFixModule.java`

在现有 Profile 和 C3 Hook 注册之后调用独立诊断类。传入包名、相机版本、映射 Profile 和已识别的 Phoenix 配置链状态；诊断类内部再次完整检查所有门槛。

没有改变现有 `DualStyleCaptureHooks.install(...)` 调用，也没有向 `DualStyleCaptureHooks`、`ZoomHooks` 或 `OemHooks` 追加诊断分支。

### `app/src/main/java/com/handlefix/ShutterHoldBurstDiagnostics.java`

新增独立的 Phoenix 快门诊断类。方法定位使用真实类加载器上的精确类名、方法名、参数类型和返回类型匹配；不使用 JADX 展示别名作为挂载依据。

### `analysis/hold-burst-phoenix-diag-v1/REPORT.md`

本文件是本轮独立执行报告，未提交。

未修改以下内容：

- `app/src/main/assets/handlefix-src-12.0.83.zip`；
- `DualStyleCaptureHooks.java`、`ZoomHooks.java`、`ModeConfig.java` 的现有实现；
- 更新日志、README、使用说明和发布文档；
- 既有 `STATUS.md`、分析资料、诊断资料和测试资产。

## 3. 诊断安装门槛

只有以下条件同时满足时，`ShutterHoldBurstDiagnostics.installIfSupported(...)` 才通过 `HandleFixModule.install(...)` 安装 Hook：

1. `BuildConfig.HOLD_BURST_DIAGNOSTIC == true`；
2. 包名严格为 `com.android.camera`；
3. `CameraBuilds.isPhoenix030(cameraVersionCode)` 为真，即严格等于 `760000300`；
4. `HandleFixModule` 已将版本识别为 `phoenix-os4`，并传入 `configChainRecognized=true`。

普通无参数 release 构建会在第一道 BuildConfig 门直接返回，不安装诊断 Hook。

## 4. 精确诊断 Hook

以下是源码中请求或实际安装的精确签名。所有回调都只读取参数、事务快照和原始返回值。

| 实际类 | 方法与参数 | 返回类型 / dex 描述符 | 作用 |
|---|---|---|---|
| `com.android.camera.module.Camera2Module` | `onKeyDown(int, android.view.KeyEvent)` | `boolean` / `(ILandroid/view/KeyEvent;)Z` | 记录 `ACTION_DOWN`、第一次 repeat，并在重复事件首次跨过阈值时记录事务节点 |
| `com.android.camera.module.Camera2Module` | `onKeyUp(int, android.view.KeyEvent)` | `boolean` / `(ILandroid/view/KeyEvent;)Z` | 记录 `ACTION_UP`、持续时长和抬键后的事务汇总 |
| `com.android.camera.module.Camera2Module` | `performKeyClicked(int, java.lang.String, android.view.KeyEvent, boolean)` | `void` / `(ILjava/lang/String;Landroid/view/KeyEvent;Z)V` | 记录 `triggerMode`、`pressed` 和 `KeyEvent.repeatCount` 的变化 |
| `com.android.camera.module.Camera2Module` | `performKeyClicked(int, java.lang.String, int, boolean)` | `void` / `(ILjava/lang/String;IZ)V` | 已验证旧链的精确回退探针；当前 Phoenix-0.3.0 以 KeyEvent 变体为准，只有当前变体不存在时才尝试 |
| `com.android.camera.module.Camera2Module` | `onPictureTakenFinished(boolean, long, int)` | `void` / `(ZJI)V` | 记录完成回调、成功状态、回调时间、图片类型和事务累计张数 |
| `com.android.camera.module.Camera2Module` | `performMiHandlePressed(int, android.view.KeyEvent)` | `void` / `(ILandroid/view/KeyEvent;)V` | 观察已由真实 smali 确认的 handle-pressed 入口 |
| `com.android.camera.module.Camera2Module` | `multiCapture()` | `boolean` / `()Z` | 观察真实 MultiCapture 启动入口及其原始返回值 |
| `com.android.camera.module.Camera2Module` | `onBurstPictureTakenFinished(boolean, long)` | `void` / `(ZJ)V` | 观察已确认的 MultiCapture/burst 完成入口 |
| `W5.d` | `O5(android.view.InputEvent)` | `boolean` / `(Landroid/view/InputEvent;)Z` | Phoenix 真实 `Q6.L.O5(InputEvent)` 具体实现；观察原始返回值 |
| `W5.d` | `Db(android.view.KeyEvent)` | `boolean` / `(Landroid/view/KeyEvent;)Z` | Phoenix 真实 `Q6.L.Db(KeyEvent)` 具体实现；观察原始返回值 |
| `l6.f` | `onShutterButtonLongClick()` | `boolean` / `()Z` | 观察已确认的原生 long-click 入口及原始返回值 |
| `l6.f` | `onShutterButtonLongClickCancel(boolean)` | `void` / `(Z)V` | 观察已确认的原生 long-click-cancel 入口 |

### `o3.c.V1` / `o3.c.r4` 的处理

Handoff 要求的两个名称仍在诊断安装过程中按精确签名探测：

- `o3.c.V1(android.view.InputEvent): boolean` / `(Landroid/view/InputEvent;)Z`；
- `o3.c.r4(android.view.KeyEvent): boolean` / `(Landroid/view/KeyEvent;)Z`。

对当前 Phoenix-0.3.0 的真实 smali 核对结果是：`o3.c` 的真实描述符为 `Lo3/c;`，它是枚举，没有上述两个方法。因此本包不会根据 JADX 别名猜测或挂载这两个 Hook，日志会记录方法不可用状态。

当前真实调用链已精确确认：

- `Camera2Module.lambda$performKeyClicked$45/48` 调用 `Q6.L.O5(InputEvent)`；
- `Camera2Module.lambda$performMiHandlePressed$50` 调用 `Q6.L.Db(KeyEvent)`；
- `W5.d` 是 `Q6.L` 的具体实现。

所以本包观察 `W5.d.O5` 和 `W5.d.Db` 作为当前 Phoenix 的实际等价决策点；这不是对 `o3.c` 的替换，也不改变任何原始结果。

## 5. 事务与日志规则

统一前缀为：`[HandleFix][hold-burst-diag]`。

一次物理事务使用 `ACTION_DOWN` 的 `downTime` 关联。事务快照包含：

- `Process.myPid()`；
- Camera2Module 的 `System.identityHashCode`；
- `moduleId=163`；
- 快门 `keyCode`（27 或 170）、`scanCode`；
- `action`、`repeatCount`、`downTime`、`eventTime`、`duration`；
- 快门短按配置、长按配置、长按阈值；
- `longConfigIsDualStyleCapture` 布尔标志，用于识别长按配置是否为 `F_DUAL_STYLE_CAPTURE`，但不干预它；
- `O5/V1` 和 `Db/r4` 各自的最后原始判断；
- `performKeyClicked` 的 `triggerMode`、`pressed`、`repeatCount`；
- `onPictureTakenFinished` 的回调时间、图片类型、回调累计数和成功累计数。

节流节点：

- `ACTION_DOWN` 且 `repeatCount=0`：建立事务并输出一次完整快照；
- 第一次 repeat：输出一次；
- 第一次持续时间跨过长按阈值：输出一次；如果只在 ACTION_UP 才跨阈值，则在抬键节点补记一次；
- `O5` / `V1` 与 `Db` / `r4`：同一事务内首次得到原始判断或判断变化时输出；四个决策点分别维护状态；
- `performKeyClicked`：首次调用或 `triggerMode` / `pressed` 发生变化时输出，包含当次 repeatCount；
- `onPictureTakenFinished`：第 1、2、3 次回调，以及此后的每 10 次回调；同时输出成功状态和累计张数；
- 原生 long-click、long-click-cancel、MultiCapture 启动/返回/完成入口：仅在活动诊断事务存在时观察并输出；
- `ACTION_UP`：输出完整事件；原始 `onKeyUp` 返回值只附在抬键后的汇总行中；
- `ACTION_UP` 后：保留事务的纯计数状态最多 3000 ms，以固定抬键时刻计时，不创建 Handler、定时任务或延迟拍摄。

配置值只在事务建立的 `ACTION_DOWN` 阶段读取并保存到事务；后续 repeat、决策、完成回调和汇总均使用快照。读取复用 `ModeConfig` 现有缓存，不在热路径重复读取配置文件。

## 6. 不改变相机行为的审计

`ShutterHoldBurstDiagnostics.java` 中没有以下行为：

- 没有 `setResult` 或 `XC_MethodReplacement`；
- 没有给 `param.args` 赋值；
- 没有写 SharedPreferences、HandleFix 配置或相机原生偏好；
- 没有改写 `attr_shutter`、`capture`、`burst_shot` 等状态；
- 没有伪造 KeyEvent、触摸事件或调用拍照/连拍入口；
- 没有使用 Handler、`sleep`、`postDelayed` 驱动拍摄；
- 决策 Hook 在 `afterHookedMethod` 读取原始返回对象，不写回结果；
- 所有目标方法均使用精确签名匹配，类或方法不在真实 dex 中时记录缺失并停止该点，不以模糊签名继续猜测。

因此诊断包只增加观察日志和内存中的短期计数；它不消费输入、不改变方法参数、不改变返回值，也不主动推进相机生命周期。

## 7. 构建与验证

### 7.1 诊断构建

使用的环境：

```powershell
$env:JAVA_HOME='D:\DevTools\jdks\jdk-21.0.12.1+1'
$env:ANDROID_HOME='D:\DevTools\AndroidSdk'
$env:ANDROID_SDK_ROOT='D:\DevTools\AndroidSdk'
.\gradlew.bat :app:assembleRelease -PholdBurstDiag=true --no-daemon
```

最终诊断构建结果：`BUILD SUCCESSFUL`。

### 7.2 诊断 APK

绝对路径：

`C:\Users\Ryan\Documents\Codex\2026-08-01\new-chat\work\ui_rewrite\outputs\Xiaomi14Ultra摄影手柄功能拓展_v12.0.98-HOLD-BURST-PHOENIX-DIAG-TEST.apk`

- 文件大小：`9,478,594` bytes；
- SHA-256：`77A63C5FB7B819D7DACA850ED28326110301FA4149285769B7EE332412B3292F`；
- 包名：`com.handlefix.all`；
- `versionName`：`12.0.98-HOLD-BURST-PHOENIX-DIAG-TEST`；
- `versionCode`：`1301`；
- `apksigner verify --verbose`：v3 `true`，签名者数量 `1`；
- ZIP 内 `assets/handlefix-src-*.zip` 数量：`1`；
- 唯一内置源码包：`assets/handlefix-src-12.0.83.zip`，ZIP 条目长度 `3,313,343` bytes；
- 未生成、未夹带新的 12.0.98 源码 ZIP。

### 7.3 默认构建回归

使用无属性命令完成最终默认构建：

```powershell
$env:JAVA_HOME='D:\DevTools\jdks\jdk-21.0.12.1+1'
$env:ANDROID_HOME='D:\DevTools\AndroidSdk'
$env:ANDROID_SDK_ROOT='D:\DevTools\AndroidSdk'
.\gradlew.bat :app:assembleRelease --no-daemon
```

结果：`BUILD SUCCESSFUL`。

默认构建生成的 `BuildConfig` 与清单核对为：

- `APPLICATION_ID=com.handlefix.all`；
- `VERSION_NAME=12.0.97`；
- `VERSION_CODE=1300`；
- `HOLD_BURST_DIAGNOSTIC=false`；
- 默认 APK 清单同样为 `com.handlefix.all / 12.0.97 / 1300`。

这证明不带 `-PholdBurstDiag=true` 时诊断安装门默认关闭，版本元数据保持 v12.0.97 基线。

### 7.4 静态与 Git 检查

- `git diff --check`：通过，退出码 `0`；
- 诊断类禁止行为扫描：未发现 `setResult`、`XC_MethodReplacement`、`param.args` 赋值、Handler/sleep/postDelayed、伪造触摸/按键或拍摄入口模式；
- 未运行 ADB 安装、设备修改或重启。

最终 `git status --short`：

```text
 M app/build.gradle.kts
 M app/src/main/java/com/handlefix/HandleFixModule.java
?? STATUS.md
?? analysis/
?? app/src/main/java/com/handlefix/ShutterHoldBurstDiagnostics.java
?? app/src/test-assets/
?? diagnostics/
?? outputs/
```

其中 `STATUS.md`、既有分析/诊断/测试资产和 `outputs/` 是基线中已存在的未跟踪资料；本轮没有清理或整体加入 Git。新增的诊断报告和 APK 也仍保持未提交状态。

## 8. 尚未确认的原生连拍入口与风险

1. 没有实机安装和运行日志，因此尚未确认 Phoenix 在用户配置为“快门长按未设置”时是否会自然进入原生 MultiCapture，也没有确认真实连拍张数、停止时机或底层 HAL 行为。
2. Handoff 指定的 `o3.c.V1` / `o3.c.r4` 在真实 Phoenix-0.3.0 dex 中不存在；当前包只能报告其缺失，并观察真实 `W5.d.O5` / `W5.d.Db` 等价实现，不能把两者视为同一个类名。
3. `multiCapture()` 与 `onBurstPictureTakenFinished(boolean,long)` 是真实可确认的启动/完成入口，但底层 `mMultiCap` 的内部停止状态和所有异步完成路径仍未完全确认；本轮没有继续猜测或挂载混淆方法。
4. 完成回调没有携带按键 `downTime`；当前按 Camera2Module 实例关联事务，并在抬键后保留最多 3000 ms。若相机重建模块实例，或上一事务的完成回调与下一次物理按键交错，仍需实机日志审计归属边界。
5. 诊断包保留 v12.0.97 既有 C3 生产 Hook；实机诊断前应按主会话要求将普通拍照短按设为单张、长按设为未设置，并避免 C3/静态高速连拍配置干扰。诊断类本身不会干预 C3。

本轮到此停止，等待主会话审计和下一步指令。
