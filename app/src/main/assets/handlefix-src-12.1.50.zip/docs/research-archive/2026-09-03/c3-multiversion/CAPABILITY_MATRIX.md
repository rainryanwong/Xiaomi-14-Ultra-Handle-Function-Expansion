# C3 双风格拍摄多版本能力矩阵

更新时间：2026-08-30

## 已实机确认

| 相机 | versionCode | 模式 | 结论 |
|---|---:|---|---|
| Phoenix-0.3.0 | 760000300 | 普通拍照 163 | 四轮成功；按住约 501–502 ms 时完成逻辑释放并开始 CV 切换，不依赖物理 ACTION_UP；第二张完成后恢复初始 CV。 |

## 已静态核对、待逐版本实机测试

| 相机 | versionCode | 按键分发 | 首帧 | 拍摄完成 | 第二拍入口 |
|---|---:|---|---|---|---|
| 官方 6.4.000370 | 640003700 | `performKeyClicked(int,String,KeyEvent,boolean)` | `notifyFirstFrameArrived(int)` | `onPictureTakenFinished(boolean,long,int)` | `mCameraAction.onShutterButtonClick(int)` |
| 官方 6.4.000530 | 640005300 | 同 6.4 新链（dex dump 已核对） | `notifyFirstFrameArrived(int)` | `onPictureTakenFinished(boolean,long,int)` | `mCameraAction.onShutterButtonClick(int)` |
| 官方 6.6.000510 | 660005100 | `performKeyClicked(int,String,KeyEvent,boolean)` | `notifyFirstFrameArrived(int)` | `onPictureTakenFinished(boolean,long,int)` | `mCameraAction.onShutterButtonClick(int)` |
| NRV-1.6.1 | 750005601 | `performKeyClicked(int,String,KeyEvent,boolean)` | `notifyFirstFrameArrived(int)` | `onPictureTakenFinished(boolean,long,int)` | `mCameraAction.onShutterButtonClick(int)` |
| V5.1 | 510011302 | `performKeyClicked(int,String,int,boolean)` | `notifyFirstFrameArrived()` | `onPictureTakenFinished(boolean,long,int)` | `Camera2Module.onShutterButtonClick(int)` |

NRV 75xxxxxxx 版本族只进入“允许探测”候选门；运行时必须同时匹配 `onKeyDown`、`onKeyUp`、`performKeyClicked`、`startNormalCapture`、`onPictureTakenFinished`、`notifyFirstFrameArrived` 和原生第二拍入口，否则 `ready=false`，模块不消费快门事件。

## 模式范围

测试包复用 `ModeConfig.isLeicaStyleMode()` 白名单：

- 普通拍照 163
- 专业拍照 167
- 夜景 173
- 人像 171
- 街拍 225
- 街拍特别款配置别名 229（仅配置别名开关启用时）

各模式必须真实走 `Camera2Module` 的上述生命周期；UI 可见不代表已经实机通过。若子模块覆盖某个关键方法且不经过基类 Hook，运行时日志会暴露缺失阶段，不能用固定延时补齐。

## 关键设计约束

- 第一张由相机原生 ACTION_DOWN 拍摄。
- 达到长按阈值后，把当前真实 repeat 的 `pressed` 语义改为 `false`，让目标相机完成本次快门逻辑释放；不构造 KeyEvent、不等待物理松键。
- 第一张与第二张只由真实 `onPictureTakenFinished` 推进。
- CV 切换后只由新预览的首帧回调请求第二拍。
- 第二拍复用目标相机的原生 `onShutterButtonClick(int)`，不直接调用 `startNormalCapture`。
- 失败或超时必须读回并恢复初始 CV；读回为 UNKNOWN 时不盲目再切一次。
