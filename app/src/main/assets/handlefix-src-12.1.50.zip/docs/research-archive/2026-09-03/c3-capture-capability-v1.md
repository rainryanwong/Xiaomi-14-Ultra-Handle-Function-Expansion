# C3 双风格拍摄：第一轮静态能力表

更新时间：2026-08-29
范围：只读静态分析；本轮尚未启用双风格拍摄状态机。

## 结论

Phoenix-0.3.0、NRV 以及官方 6.4.000370/530、OS4 6.6.000510 的
`com.android.camera.module.Camera2Module` 均保留了同形的最终完成回调：

```text
onPictureTakenFinished(boolean, long, int) -> void
Lcom/android/camera/module/Camera2Module;onPictureTakenFinished(ZJI)V
```

该回调比底层 `onCaptureCompleted(boolean)` 更接近 JPEG/相册收尾，适合作为
第一张照片完成后再切换徕卡状态的候选同步点。但仍需诊断包在真实设备上确认：
普通拍照一次是否只产生一次成功回调，以及 HDR/多帧是否会产生额外回调。

## 方法描述符

所有下列方法均来自实际反编译源码中的 `Camera2Module`，不是 JADX 为字段生成的别名。

| 相机样本 | versionCode | 快门事件 | 原生拍摄候选 | 完成回调 |
|---|---:|---|---|---|
| Phoenix-0.3.0 | 760000300 | `onKeyDown(I,KeyEvent)Z` / `onKeyUp(I,KeyEvent)Z`；`performKeyClicked(ILjava/lang/String;KeyEvent;Z)V` | `startNormalCapture(I)Z` | `onPictureTakenFinished(ZJI)V` |
| NRV-1.6.1 | 750005601 | 同形 | `startNormalCapture(I)Z` | `onPictureTakenFinished(ZJI)V` |
| 官方 6.4.000370 | 640003700 | 同形 | `startNormalCapture(I)Z` | `onPictureTakenFinished(ZJI)V` |
| 官方 6.4.000530 | 640005300 | 同形 | `startNormalCapture(I)Z` | `onPictureTakenFinished(ZJI)V` |
| 官方 OS4 6.6.000510 | 660005100 | 同形 | `startNormalCapture(I)Z` | `onPictureTakenFinished(ZJI)V` |

各版本同时保留：

```text
onCaptureCompleted(Z)V
```

它是 Camera2 管线完成通知，可能早于 JPEG 保存和相册状态收尾，因此暂不作为
C3 第二张拍摄的唯一依据，只在诊断包中记录对照时间。

## 版本差异

- `Camera2Module` 的生命周期方法形状一致，但 `mCameraAction` 的具体混淆类型和
  `onShutterButtonClick` 所在类并不保证一致。
- 后续实现不能把 Phoenix 的 `p391l6.C2089f` 名称直接套到 NRV 或官方相机。
- 徕卡 CV 类型读取/切换已有 Phoenix 与非 Phoenix 两条适配链，但切换后仍要读回确认。
- 第一阶段只考虑普通拍照 moduleId 163；夜景、专业、人像和连拍的回调语义需另行验证。

## 诊断包记录内容

诊断构建会在 LSPosed/相机日志中记录：

1. 27/170 快门键 `onKeyDown`、`onKeyUp` 的 action、repeatCount、时间戳和当前 moduleId；
2. `performKeyClicked` 与 `doKeyShutterSnap` 是否被调用；
3. `startNormalCapture` 的参数和布尔结果；
4. `onCaptureCompleted` 的次数；
5. `onPictureTakenFinished` 的 success、timestamp、type、回调次数和当时 CV 状态；
6. 每个实际挂载方法的完整 JVM descriptor。

所有诊断 Hook 都是观察型 Hook，不设置返回值、不消费按键、不调用第二次拍摄。

## 下一步判定标准

普通拍照中，若一次快门只出现一个 `startNormalCapture` 接受结果和一个
`onPictureTakenFinished(success=true)`，且回调在保存流程稳定结束后到达，则可以在
单独的 Phoenix-0.3.0 适配器中实现 C3 原型。若出现多次完成回调，需按 `timestamp/type`
和相机内部拍摄状态进一步过滤，不能直接进入第二张拍摄。
