# 快门长按原生高速连拍能力矩阵

基线：`v12.0.97` / `c88f0e8`。本表只描述测试包的候选与真实 dex 入口，
不代表未经实机测试的版本已经验收。

## 模式范围

| moduleId | 模式 | 结论 |
|---:|---|---|
| 163 | 普通拍照 | 开放测试；相机原生具备长按 MultiCapture 与松手停止链 |
| 225 | 街拍 | 开放测试；复用相机原生拍照长按链，仍需逐版本实机验证 ACTION_UP |
| 171 | 人像 | 不开放；用户确认且原生能力证据均表明不具备高速连拍 |
| 173 | 夜景 | 不开放；用户确认且原生能力证据均表明不具备高速连拍 |
| 167 | 专业拍照 | 不开放；用户确认且原生能力证据均表明不具备高速连拍 |

## 相机版本

| 相机 | versionCode / Profile | 原生决策入口 | 本包状态 |
|---|---|---|---|
| Phoenix-0.3.0 | `760000300` / Phoenix | `lambda$performMiHandlePressed$50(KeyEvent,Q6.L):Boolean` | 163 已实机通过；225 开放测试 |
| 官方 OS4 6.6.000510.0 | `660005100` / official | `lambda$performMiHandlePressed$50(KeyEvent,Q6.L):Boolean` | 163/225 开放测试 |
| NRV-1.3.2 | `660005100` / Prometheus | `lambda$performMiHandlePressed$50(KeyEvent,Q6.L):Boolean` | 163/225 开放测试 |
| 官方 OS3 6.4.000370.0 | `640003700` / official | `lambda$performMiHandlePressed$49(KeyEvent,V3.J):Boolean` | 163/225 开放测试 |
| 官方 OS3 6.4.000530.0 | `640005300` / official | `lambda$performMiHandlePressed$49(KeyEvent,X3.J):Boolean` | 163/225 开放测试 |
| NRV-1.5.0 | `750005500` / Prometheus | `lambda$performMiHandlePressed$49(KeyEvent,f4.K):Boolean` 同族链 | 163/225 开放测试；以运行时完整签名二次门控 |
| NRV-1.6.1 | `750005601` / Prometheus | `lambda$performMiHandlePressed$49(KeyEvent,f4.K):Boolean` | 163/225 开放测试 |
| Prometheus V5.1 | `510011302` / Prometheus | 旧式 `performKeyClicked(int,String,int,boolean)` | 本包不开放；缺少 KeyEvent downTime 与已验证 release 闭环，需单独窄诊断 |

## 决策原则

- 版本号只允许进入候选；运行时还必须匹配完整返回类型与参数形状。
- `$49/$50` 不能互换猜测；控制器按版本族选择真实序号，并要求第二参数为接口。
- 初始 DOWN 始终保留原生单张；达到用户阈值后才覆盖本事务的原生 Boolean 决策。
- 不直接调用 `multiCapture()`，不使用定时循环、伪造 KeyEvent、触摸注入或相机偏好写入。
- ACTION_UP 不消费，先让相机原生停止链完成，再清理模块事务。
