# Phoenix-0.3.0 快门长按原生高速连拍功能测试包执行报告

日期：2026-08-30
范围：Phoenix-0.3.0，精确 `versionCode=760000300`，普通拍照 `moduleId=163`，手柄快门 `keyCode=27/170`。
构建类型：第一版功能测试包；本轮没有安装 APK、重启设备、提交或推送。

## 1. 基线与范围

本轮在以下仓库工作树完成：

`C:\Users\Ryan\Documents\Codex\2026-08-01\new-chat\work\ui_rewrite`

只读复核结果：

- 分支：`master`
- `HEAD`：`c88f0e847fe11fa49a05dbaa54df8421ea38a92e`（`c88f0e8 release: v12.0.97 consolidate C3 capture state`）
- `origin/master`：与 `HEAD` 一致
- 上一轮 `holdBurstDiag` 修改、`ShutterHoldBurstDiagnostics.java`、诊断报告和既有资料目录均保留，未清理、覆盖或加入 Git。
- 未更新 `app/src/main/assets/handlefix-src-12.0.83.zip`，未创建新的源码 ZIP。

本轮没有扩展到其它相机版本、其它 module、其它按键或其它拍摄模式。初始 DOWN 不直接进入连拍；只有同一物理按键事务在已有 repeat 事件上达到快门长按阈值后，才切换到已核实的 Phoenix 原生长按路由。

## 2. 修改文件

本轮新增/修改：

- `app/build.gradle.kts`
  - 新增项目属性 `holdBurstTest`，默认 `false`。
  - 新增 `BuildConfig.HOLD_BURST_TEST`，默认 `false`。
  - 保留上一轮 `holdBurstDiag` / `BuildConfig.HOLD_BURST_DIAGNOSTIC` 门控。
  - `-PholdBurstTest=true` 时使用 `12.0.99-HOLD-BURST-PHOENIX-TEST / 1302`；不带属性仍使用 `12.0.97 / 1300`。
- `app/src/main/java/com/handlefix/ModeConfig.java`
  - 确认未占用的功能码 `6` 为 `F_HOLD_BURST`。
  - 将既有 `normalizeShutterConflict` 最小泛化为“短按静态高速连拍 + 任一独占长按动作（C3 或 F_HOLD_BURST）”的统一规则。
  - 设置独占长按时保留长按并把短按改为 `F_SHUTTER`；设置短按高速连拍时清空独占长按；导入旧配置沿用保留独占长按的归一化策略。
- `app/src/main/java/com/handlefix/ui/KeyConfigActivity.kt`
  - 只在测试包、精确 Phoenix-0.3.0、普通拍照 163、快门长按页显示“长按高速连拍”。
  - 保留“双风格拍摄”原有显示和能力门。
  - 两种冲突设置均沿用同一确认弹窗逻辑，并按实际动作动态显示“长按高速连拍”或“双风格拍摄”。
- `app/src/main/java/com/handlefix/ShutterHoldBurstController.java`
  - 新增独立生产测试控制器，承载事务状态机、所有权、阈值切换和清理逻辑。
- `app/src/main/java/com/handlefix/OemHooks.java`
  - 仅在既有 Phoenix OS4 两个决策 Hook 的最前面增加 Controller resolver 桥接；未改变 C3 分支语义。
- `app/src/main/java/com/handlefix/HandleFixModule.java`
  - 在 Phoenix 配置链识别后调用 Controller 的完整版本/包名/Profile 门控。

上一轮已有的 `app/src/main/java/com/handlefix/ShutterHoldBurstDiagnostics.java` 和
`analysis/hold-burst-phoenix-diag-v1/REPORT.md` 本轮保留，功能测试构建没有安装诊断 Hook，因为没有传入 `-PholdBurstDiag=true`。

## 3. 精确 Hook 签名与接入方式

Controller 对 `com.android.camera.module.Camera2Module` 使用精确返回类型和参数类型匹配；不根据 JADX 别名匹配，也不使用宽泛的方法名扫描。

Controller 自己直接挂载的生命周期 Hook：

| 类 | 方法精确签名 | 用途 |
|---|---|---|
| `com.android.camera.module.Camera2Module` | `boolean onKeyDown(int, android.view.KeyEvent)`；dex：`(ILandroid/view/KeyEvent;)Z` | `repeatCount=0` 建立事务；后续 repeat 推进阈值状态 |
| `com.android.camera.module.Camera2Module` | `boolean onKeyUp(int, android.view.KeyEvent)`；dex：`(ILandroid/view/KeyEvent;)Z` | 标记 `RELEASING`，after 回调清理 |
| `com.android.camera.module.Camera2Module` | `void performKeyClicked(int, java.lang.String, android.view.KeyEvent, boolean)`；dex：`(ILjava/lang/String;Landroid/view/KeyEvent;Z)V` | 观察已进入手柄点击路径的 repeat，并补充阈值推进 |
| `com.android.camera.module.Camera2Module` | `void performKeyClicked(int, java.lang.String, int, boolean)`；dex：`(ILjava/lang/String;IZ)V` | 已核实旧版 repeatCount 变体的精确兼容候选；Phoenix 当前主路径使用上一个 KeyEvent 变体 |

两个已核实的原生决策点仍由既有 Phoenix `OemHooks` 安装，Controller 通过 resolver 接入，避免重复安装同一方法：

| 类 | 方法精确签名 | Controller 行为 |
|---|---|---|
| `com.android.camera.module.Camera2Module` | `boolean isNeedBurst(int, android.view.KeyEvent)`；dex：`(ILandroid/view/KeyEvent;)Z` | `PRESSED_SINGLE` 返回 `false`，`BURST_ACTIVE` 返回 `true`；只作为准确 fallback，不主动调用入口 |
| `com.android.camera.module.Camera2Module` | `static java.lang.Boolean lambda$performMiHandlePressed$50(android.view.KeyEvent, Q6.L)`；dex：`(Landroid/view/KeyEvent;LQ6/L;)Ljava/lang/Boolean;` | 阈值前返回 `false` 走 `doKeyShutterSnap`；阈值后返回 `true` 走已核实的 `doKeyShutterLongPress` 原生链 |

静态 lambda 的 `thisObject` 在 Xposed 回调中为空，因此 Controller 使用同一事务的 `downTime` 查找活动事务，并额外用 `HandleFixModule.CURRENT_MODE` 在已知模式切换时清理；事务本身仍保存 Camera2Module 实例 identity、downTime 和起始 moduleId。

Controller 安装完整门控为：

`BuildConfig.HOLD_BURST_TEST == true`、包名 `com.android.camera`、`CameraBuilds.isPhoenix030(versionCode)`、Phoenix 配置链已识别、Profile 为 `phoenix-os4`。事务门控再要求当前 moduleId 为 163、keyCode 为 27 或 170、长按配置精确为 `F_HOLD_BURST`。

## 4. 状态机、所有权与按键路由

状态严格为：

`IDLE -> PRESSED_SINGLE -> BURST_ACTIVE -> RELEASING -> IDLE`

- `ACTION_DOWN + repeatCount=0`：读取一次短按配置、长按配置和阈值快照。只有长按配置是 `F_HOLD_BURST` 才建立事务；事务初始为 `PRESSED_SINGLE`。
- 初始 DOWN 的 lambda 决策为 `false`，因此保留 Phoenix 原生 `doKeyShutterSnap` 的首张单拍，不提前启动连拍。
- `repeatCount>0` 且 `eventTime-downTime >= shutterLongPressMs`：同一事务只执行一次状态转换为 `BURST_ACTIVE`。在下一次已核实的 lambda/isNeedBurst 决策点返回 `true`，让相机调用 `doKeyShutterLongPress(..., true)` 原生链。
- 阈值前的所有 repeat 决策仍返回 `false`；不会因为 repeat 本身额外拍照。
- `ACTION_UP`：Controller 只标记 `RELEASING`，不设置返回值、不修改参数、不消费按键；先让 Camera2Module 原生 release/long-click-cancel 路径执行，随后在 `onKeyUp` after 清理事务。
- 新的实例、已知模式切换和超时只清理 Controller 状态，不主动停止、补拍或重新触发相机入口。
- 状态存储使用以 Camera2Module 实例为键的弱映射；事务字段包含 `moduleIdentity + downTime + moduleId`，同时校验 keyCode 和事件 downTime，避免不同物理按键事务串线。

Controller 没有 `Handler`、`sleep`、`postDelayed` 或定时循环；阈值只在相机已经送达的 repeat 事件上判断。没有伪造 KeyEvent、触摸事件、相机偏好、`attr_shutter`、`capture`、`burst_shot` 或配置文件写入，也没有直接调用 `multiCapture()`。因此第一版的连拍启动责任仍在相机已确认的原生长按链，模块只在精确事务和阈值后改变该链的布尔路由。

测试日志前缀为 `[HandleFix][hold-burst-test]`，只输出事务建立、阈值跨越、首次原生 burst route、ACTION_UP、清理和异常；没有复制上一轮诊断类中每个 repeat 的热路径日志。

## 5. C3 隔离与冲突归一化

- Controller 不调用、不复用、不修改 `DualStyleCaptureHooks` 状态机。
- `F_DUAL_STYLE_CAPTURE` 和 `F_HOLD_BURST` 都被视为独占长按动作，但长按配置值本身仍然只有一个。
- 当短按为 `F_BURST`、用户设置长按为 `F_HOLD_BURST` 或 C3 时，统一归一化将短按改为 `F_SHUTTER`，然后显示确认弹窗。
- 当长按已为 `F_HOLD_BURST` 或 C3、用户把短按改为 `F_BURST` 时，统一归一化将对应长按清为 `F_DEFAULT`，然后显示确认弹窗。
- 导入旧配置时优先保留独占长按动作，再把短按改为单张；不存在第二套冲突归一化实现。
- 普通版本构建中 `HOLD_BURST_TEST=false`，列表能力门会移除 F_HOLD_BURST，Controller 安装门直接返回；已有 C3 的生产语义不变。

## 6. 构建与 APK 验证

测试构建使用的命令：

```powershell
$env:JAVA_HOME='D:\DevTools\jdks\jdk-21.0.12.1+1'
$env:ANDROID_HOME='D:\DevTools\AndroidSdk'
$env:ANDROID_SDK_ROOT='D:\DevTools\AndroidSdk'
.\gradlew.bat :app:assembleRelease -PholdBurstTest=true --no-daemon
```

结果：`BUILD SUCCESSFUL`。测试包已复制到：

`C:\Users\Ryan\Documents\Codex\2026-08-01\new-chat\work\ui_rewrite\outputs\Xiaomi14Ultra摄影手柄功能拓展_v12.0.99-HOLD-BURST-PHOENIX-TEST.apk`

测试 APK 静态核验：

- 文件大小：`9,494,961` bytes
- 包名：`com.handlefix.all`
- `versionName`：`12.0.99-HOLD-BURST-PHOENIX-TEST`
- `versionCode`：`1302`
- `apksigner verify --verbose`：`Verified using v3 scheme (APK Signature Scheme v3): true`
- APK 内源码归档数量：`1`
- 唯一源码归档：`assets/handlefix-src-12.0.83.zip`，未生成新的 12.0.99 源码包
- SHA-256：`65757E1C01723BB3EB6895B544556C277409E100B73AAE72ECB37A3695D90D76`

默认回归使用的命令：

```powershell
$env:JAVA_HOME='D:\DevTools\jdks\jdk-21.0.12.1+1'
$env:ANDROID_HOME='D:\DevTools\AndroidSdk'
$env:ANDROID_SDK_ROOT='D:\DevTools\AndroidSdk'
.\gradlew.bat :app:assembleRelease --no-daemon
```

结果同样为 `BUILD SUCCESSFUL`。无属性构建静态核验：

- 包名：`com.handlefix.all`
- `versionName`：`12.0.97`
- `versionCode`：`1300`
- 生成的 `BuildConfig`：`HOLD_BURST_DIAGNOSTIC=false`、`HOLD_BURST_TEST=false`
- 默认 APK v3 签名验证通过
- 默认 APK 内仍只有 `assets/handlefix-src-12.0.83.zip`
- 默认 APK SHA-256：`2A5E42E74F81D7452494F4E5C6F7EFD47C352225633810651C905BD3D0BC1B76`
- 默认 APK 大小：`9,494,935` bytes

`git diff --check`：通过。执行期间只看到既有的 CRLF 转换提示、Android API 弃用警告及 SDK 目录位置提示，没有 diff whitespace 错误。

报告生成后的 `git status --short` 快照：

```text
 M app/build.gradle.kts
 M app/src/main/java/com/handlefix/HandleFixModule.java
 M app/src/main/java/com/handlefix/ModeConfig.java
 M app/src/main/java/com/handlefix/OemHooks.java
 M app/src/main/java/com/handlefix/ui/KeyConfigActivity.kt
?? STATUS.md
?? analysis/
?? app/src/main/java/com/handlefix/ShutterHoldBurstController.java
?? app/src/main/java/com/handlefix/ShutterHoldBurstDiagnostics.java
?? app/src/test-assets/
?? diagnostics/
?? outputs/
```

其中 `STATUS.md`、`analysis/`、`app/src/test-assets/`、`diagnostics/` 和 `outputs/` 是基线中已有的用户资料/资产目录；本轮未清理或整体加入 Git。

## 7. 尚未确认的风险与停止点

本轮明确没有 ADB 安装和实机验证，因此以下事项仍需主会话审计/后续实机测试确认：

1. 已由真实 Phoenix smali 确认 `lambda$performMiHandlePressed$50` 返回 `true` 会进入 `doKeyShutterLongPress(..., true)`，但本轮尚未在设备上确认该路由实际启动 `MultiCapture`、实际帧率/张数和原生上限。
2. 尚未确认 `ACTION_UP` 经过 Phoenix 原生链后一定触发 MultiCapture stop 或 long-click-cancel；Controller 有意不消费 ACTION_UP，也没有自行补发停止事件。
3. `isNeedBurst` 是精确 fallback，Phoenix 手柄 O5=true 主路径仍预计是 `performMiHandlePressed`；尚未在功能包上观察两条路径的实际调用顺序。
4. 功能测试类没有挂载 `onPictureTakenFinished` 计数 Hook，因此本包日志不会给出完成张数统计；这避免把上一轮诊断热路径带入功能包，但也意味着张数需由主会话实机日志/相册结果确认。
5. 静态构建验证不能证明相机进程实际加载了 Phoenix 的精确方法；若后续 APK 改变真实 descriptor，应重新以目标 APK dex 为准定位，不能沿用别名。

本报告生成后停止继续开发，等待主会话完成代码审计并发送下一步指令。
