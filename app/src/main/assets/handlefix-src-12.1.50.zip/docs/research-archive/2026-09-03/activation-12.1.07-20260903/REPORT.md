# 12.1.07 启用检测阻塞：只读排查

时间：2026-09-03 08:01–08:10 CST。设备 6ea663f2；模块 12.1.07/1310；进程 13994。

已确认两层原因：

1. 当前手机 LSPosed v2.2.0 (7854) 不向传统模块投递现代 XposedService。直接读取设备 `/data/adb/modules/zygisk_lsposed/daemon.apk` 并反编译，`defpackage.u4.u(int,boolean)` 和 `s()` 仅在 `!ModuleInfo.a(z5.d)` 时安排服务投递；`ModuleInfo.a(int)` 返回 `i < 100`；`u1.j(String,boolean)` 的传统分支将 `z5.d=82`。HandleFix 保留 API82/xposed_init，新增 service 依赖和 Provider 不会将其变为现代模块。不能通过抬高版本元数据假装迁移。
2. `LspActivationGate` 的失败分支只有 Box 和 LeftDialog，没有 Miuix Scaffold。实际 Scaffold 在只有 ACTIVE 才创建的 MainScreen 内。检查实际依赖 miuix-ui-android 0.9.3 sources.jar，Scaffold 提供 LocalDialogStates/LocalRootDialogStates 及 MiuixPopupHost，OverlayDialog 使用该宿主。超时失败提示没有绘制宿主，用户只能看到检测文字。

运行证据：07:57:34.841 LSPosed 已输出 `[HandleFixSys] SystemHandleFix: installed in system_server`，因此不能把界面未收到服务当作模块未启用。模块 Activity 在 07:57:55 启动，07:58 多次恢复/旋转仍有正常绘制与输入日志；本轮过滤未见 HandleFixActivation 的连接或 IPC 异常日志，但现有实现没有完整的服务接收成功/拒收诊断，不能仅靠日志缺失证明 Binder 未到达。服务投递门限证据来自设备实际 daemon 的静态代码。

附带日志：07:58:13 LSPosed 有 IPackageManager Binder transaction failure/-28。不能把此文案直接解释成磁盘满，也不能替代上述确定的传统模块过滤条件。

建议修复：将检测层置于始终存在的独立弹窗宿主；传统 API82 使用经验证的传统启用信号/现有实时探针，不再把现代 Binder 缺失作为锁死主页的依据；保留未知/不支持检测状态，不伪造 ACTIVE。现代服务可作可选证据，不能为这项检测迁移全部 Hook 或修改 LSPosed。

本轮只读诊断，不修改功能代码、不构建、不安装、不重启、不改变作用域或手机设置、不提交推送。下一轮先确定传统检测入口，再做窄修复并实机验证已启用/未启用/不支持检测三种状态。
