# Phoenix-0.3.0 快门长按原生连拍：18:25 运行时结论

日期：2026-08-30
相机：Phoenix-0.3.0，`versionCode=760000300`
模式：普通拍照，`moduleId=163`
模块：`12.0.98-HOLD-BURST-PHOENIX-DIAG-TEST (1301)`

## 测试配置

- 快门短按：`C`（单张拍摄）
- 快门长按：`0`（未设置）
- 快门长按阈值：`500 ms`
- 物理快门：`keyCode=27`、`scanCode=212`

## 事务结果

日志中至少覆盖以下按压时长：

- `136 ms`：短按，一张成功照片。
- `552 ms`：跨过阈值，一张成功照片。
- `808 ms`：跨过阈值，一张成功照片。
- `2056 ms`：跨过阈值，一张成功照片。
- `2936 ms`：跨过阈值，一张成功照片。
- `5040 ms`：跨过阈值，持续到 `repeatCount=92`，仍只有一张成功照片。

所有长按事务的第一次 repeat 均约在 `400 ms` 到达，约在 `501–502 ms`
跨过阈值，之后约每 `50 ms` 到达一个 repeat。`ACTION_UP`、
`performKeyClicked(pressed=false)` 和 `onKeyUp originalReturn=true` 均完整到达。

没有观察到：

- `multiCapture()`；
- `onBurstPictureTakenFinished(...)`；
- 原生 `onShutterButtonLongClick()`；
- 原生 `onShutterButtonLongClickCancel(...)`；
- 第二张照片或任意 burst 完成回调；
- 相机 FATAL/ANR。

## 根因

Phoenix 手柄主路径为：

```text
Camera2Module.onKeyDown
  -> performKeyClicked(..., pressed=true)
  -> W5.d.O5(InputEvent) = true
  -> performMiHandlePressed
  -> lambda$performMiHandlePressed$50(KeyEvent, Q6.L)
```

真实 dex 中 `lambda$performMiHandlePressed$50` 的原始值为 `!Q6.L.Db(KeyEvent)`。
但当前短按配置为单张 `C`，既有 `OemHooks` 在该 lambda 的 before 回调中直接
`setResult(false)`，因此原始 `W5.d.Db` 根本不会执行。其实际效果是：

- 初始 `repeatCount=0`：执行 `doKeyShutterSnap`，拍摄首张；
- 后续 `repeatCount>0`：仍返回 false，不进入原生长按路由；
- 无论继续按住多久，都不会自然切换到 MultiCapture。

所以失败层不在系统按键 repeat，也不在松手事件，而在同一物理事务跨过阈值后
没有把已经验证的 Phoenix 原生路由从“单张”切换为“长按连拍”。

## 下一阶段方案

第一版功能测试只在 Phoenix-0.3.0、普通拍照 `163`、快门长按配置为
`F_HOLD_BURST` 时建立独立事务：

1. 初始 DOWN 保持 lambda 返回 false，首张继续使用相机原生单拍。
2. 使用现有 repeat 的 `eventTime-downTime` 判断阈值；不使用定时器。
3. 同一事务跨过阈值后，lambda 返回 true，转入相机原生长按连拍链。
4. ACTION_UP 不消费，继续由相机原生链停止连拍；原生回调返回后才清理事务。
5. 不直接调用 `multiCapture()`，不写相机偏好，不伪造按键，不与 C3 共用状态机。
