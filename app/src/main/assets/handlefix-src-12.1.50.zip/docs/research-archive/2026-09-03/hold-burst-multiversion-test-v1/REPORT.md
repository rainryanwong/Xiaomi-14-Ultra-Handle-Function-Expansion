# v12.1.00 长按原生高速连拍多版本测试包报告

## 实现边界

- 只开放快门键长按动作“长按高速连拍”。
- 只支持普通拍照 `163` 与街拍 `225`。
- C3 双风格拍摄仍是独立、互斥的长按动作，未共享状态机。
- V5.1 旧链因证据不足暂不显示该选项。
- 本轮未安装、未重启、未提交、未推送，未更新更新日志或内置源码 ZIP。

## 根因实现

`ShutterHoldBurstController` 继续以 Camera2Module 实例、`KeyEvent.downTime` 和起始
moduleId 作为事务身份：

1. `repeatCount=0` 建立事务并快照短按/长按配置与阈值，首张保持原生单张。
2. 真实 repeat 达到阈值后进入 `BURST_ACTIVE`。
3. 仅在该事务中把已验证的 `lambda$performMiHandlePressed$49/$50` 或
   `isNeedBurst(int,KeyEvent)` 决策改为原生长按路径。
4. ACTION_UP 不消费；原生长按取消/停止链执行后清理事务。
5. 模式、Camera2Module 实例或 downTime 变化时只清理，不补拍、不主动停止。

Phoenix 与官方 OS4 510 继续复用 OemHooks 已验证的 `$50` 接入点；OS3 与 NRV
由控制器对真实 `$49/$50` 形状进行精确反射挂载，避免复制每个混淆接口名。

## 代码结构

- `CameraBuilds`：集中维护现代 KeyEvent 候选版本；明确排除 V5.1 旧链。
- `CameraCapabilityRegistry`：集中维护版本与 `163/225` 模式能力门。
- `ShutterHoldBurstController`：唯一事务与原生决策覆盖实现。
- `KeyConfigActivity`：UI 使用同一能力门；不支持的版本/模式不能保存动作。
- `ModeConfig`：沿用“静态短按高速连拍 vs 独占长按动作”的统一冲突归一化。

## 禁止行为审计

控制器未出现以下行为：

- 直接调用 `multiCapture()`；
- `Handler`、`sleep`、`postDelayed` 连拍循环；
- 构造或发送伪造 KeyEvent；
- 触摸注入；
- 写入相机 `attr_shutter` / `burst_shot` 等偏好；
- 复用或修改 C3 状态机。

## 构建与验证

命令：

```powershell
$env:JAVA_HOME='D:\DevTools\jdks\jdk-21.0.12.1+1'
$env:ANDROID_HOME='D:\DevTools\AndroidSdk'
$env:ANDROID_SDK_ROOT='D:\DevTools\AndroidSdk'
.\gradlew.bat :app:assembleRelease -PholdBurstMultiTest=true --no-daemon
```

结果：`BUILD SUCCESSFUL`。

- APK：`outputs/Xiaomi14Ultra摄影手柄功能拓展_v12.1.00-HOLD-BURST-MULTI-TEST.apk`
- 包名：`com.handlefix.all`
- versionName：`12.1.00-HOLD-BURST-MULTI-TEST`
- versionCode：`1303`
- 大小：`9,494,960` bytes
- SHA-256：`F4477FCC3FB4B26F09B4B428445745EC930BB5CF91268B22CC4B487549D42A93`
- APK Signature Scheme v3：通过；签名者 1
- 内置源码资源仍只有 `assets/handlefix-src-12.0.83.zip`
- `git diff --check`：通过

无构建属性的默认 release 另行构建通过，并核对为：

- versionName `12.0.97`
- versionCode `1300`
- `HOLD_BURST_DIAGNOSTIC=false`
- `HOLD_BURST_TEST=false`
- `HOLD_BURST_MULTI_TEST=false`

## 实机待验证

- Phoenix-0.3.0 街拍 225。
- 官方 370/530/510 的 163、225。
- NRV-1.3.2/1.5.0/1.6.1 的 163、225。
- 每个组合验证短按一张、跨阈值后连续拍摄、松手立即停止、下一次短按无状态残留。
