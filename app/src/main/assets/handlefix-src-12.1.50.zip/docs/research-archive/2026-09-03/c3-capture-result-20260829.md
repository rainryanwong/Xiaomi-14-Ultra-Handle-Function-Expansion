# C3 快门长按双风格诊断结果（2026-08-29）

## 测试范围

- 相机：Phoenix-0.3.0，运行时 `versionCode=760000300`
- 模式：普通拍照，`moduleId=163`
- 画质状态：诊断日志记录为 `CV=VIBRANT`
- 操作：五次拍摄，前三次短按快门，后两次长按快门
- 诊断包：`12.0.83-C3-DIAG`，只读 Hook，不消费事件、不改拍摄流程

## 运行时证据

相册中形成的五个文件与按键时间一一对应：

| 次数 | 快门事件 | 持续时间 | 系统拍摄事件 | 文件写入时间 | 结论 |
|---:|---|---:|---|---|---|
| 1 | 09:35:29.182 DOWN → 09:35:29.563 UP | 381 ms | 09:35:29.236 | 09:35:29.419 | 短按，单张 |
| 2 | 09:35:33.660 DOWN → 09:35:33.995 UP | 335 ms | 09:35:33.700 | 09:35:33.880 | 短按，单张 |
| 3 | 09:35:37.756 DOWN → 09:35:38.043 UP | 287 ms | 09:35:37.828 | 09:35:38.009 | 短按，单张 |
| 4 | 09:35:42.292 DOWN → 09:35:46.196 UP | 3,904 ms | 09:35:42.356 | 09:35:42.537 | 长按，仍为单张 |
| 5 | 09:35:48.109 DOWN → 09:35:51.573 UP | 3,464 ms | 09:35:48.152 | 09:35:48.334 | 长按，仍为单张 |

对应文件为：

```text
IMG_20260829_093529.jpg
IMG_20260829_093533.jpg
IMG_20260829_093537.jpg
IMG_20260829_093542.jpg
IMG_20260829_093548.jpg
```

硬件事件表现为：

- 短按是一次 `KEYCODE_CAMERA(27)` DOWN/UP；前两次之前还出现独立的 `KEYCODE_FOCUS(528)` DOWN/UP，第三次没有重复发送焦点事件。
- 长按先发送一次普通 `KEYCODE_CAMERA` DOWN，约 400 ms 后开始以约 50 ms 间隔发送 repeat DOWN，松键时才发送 UP。
- 两次长按的系统 `miuicam_capture_event` 都发生在初始 DOWN 后约 43–64 ms，文件也在松键前写入；没有在松键后出现第二个拍摄事件或第二个文件。

## 对 C3 实现的判断

这组运行时资料已经确认了 C3 的关键前半段：Phoenix 的快门长按并不是“松键后才拍第一张”，而是沿用普通快门 DOWN 的单拍入口，随后 repeat 只进入长按判定。因此不能在 `onKeyUp` 上简单追加第二张，也不能把 repeat 当成第二次拍摄。

在这次早先的测试中仍缺少可安全实现双风格状态机的最后一项证据：每一次 `miuicam_capture_event` 对应的真实 `onPictureTakenFinished(boolean,long,int)` 完成时刻。诊断 Hook 已安装，但当时导出的全量 logcat 在测试后被系统高频日志滚动覆盖，当前保留下来的关键证据主要是输入事件、系统拍摄事件和文件时间；这不足以证明哪个回调时刻可以安全切换 CV 类型。该缺口已在下方 10:04 窄日志复测中补齐。

因此当时不修改正式拍摄逻辑，也不把固定延时当作“拍摄完成”。下一步应使用窄日志或独立持久化诊断只记录：

1. 初始 DOWN 对应的真实拍摄调用；
2. `onPictureTakenFinished` 的 success/timestamp/type；
3. 回调与文件落盘之间的顺序；
4. 长按 repeat 是否再次进入拍摄入口。

只有确认第 2 项后，才能以“第一张完成 → 切换 CV → 第二张 → 第二张完成 → 恢复状态”的异步状态机实现 C3；该条件已由下方 10:04 窄日志满足，正式拍摄逻辑仍待单独实现和验证。

## 本地证据文件

- `outputs/diag-c3-live-20260829/logcat-all.txt`
- `outputs/diag-c3-live-20260829/logcat-camera-filter.txt`
- `outputs/diag-c3-live-20260829/c3diag-1004-narrow.log`（10:03:40–10:04:05 窄筛选日志）

## 10:04 前后窄日志复测（Phoenix-0.3.0）

用户在同一普通拍照场景完成两轮“短按 + 长按”。本次使用诊断包的窄筛选日志，保留了完整的按键序列和拍摄完成回调；相机进程确认仍为 `versionCode=760000300`、`moduleId=163`、`CV=VIBRANT`。

| 按键序列 | 时间与持续时长 | 初始入口 | 完成回调 | 生成文件 | 结论 |
|---:|---|---|---|---|---|
| 1 | 10:03:44.102 DOWN → 10:03:44.240 UP（144 ms） | `doKeyShutterSnap` 1 次；`startNormalCapture=true` | `onCaptureCompleted=true` 10:03:44.355；`onPictureTakenFinished=true` 10:03:44.357 | `IMG_20260829_100344.jpg` | 短按单张 |
| 2 | 10:03:50.248 DOWN → 10:03:52.165 UP（1,920 ms） | `doKeyShutterSnap` 1 次；`startNormalCapture=true` | `onCaptureCompleted=true` / `onPictureTakenFinished=true` 10:03:50.488 | `IMG_20260829_100350.jpg` | 长按仍单张 |
| 3 | 10:03:55.422 DOWN → 10:03:55.565 UP（144 ms） | `doKeyShutterSnap` 1 次；`startNormalCapture=true` | `onCaptureCompleted=true` 10:03:55.685；`onPictureTakenFinished=true` 10:03:55.685 | `IMG_20260829_100355.jpg` | 短按单张 |
| 4 | 10:04:00.303 DOWN → 10:04:04.494 UP（4,192 ms） | `doKeyShutterSnap` 1 次；`startNormalCapture=true` | `onCaptureCompleted=true` / `onPictureTakenFinished=true` 10:04:00.547 | `IMG_20260829_100400.jpg` | 长按仍单张 |

关键时序：长按的首个 repeat 约在初始 DOWN 后 397–399 ms 出现，`perform_long_dispatch` 在约 548 ms 出现；但第一次 JPEG 的完成回调已在 DOWN 后约 240 ms 内完成。两次长按的 `key_up` 汇总分别为 `captureCalls=1`，没有第二次 `doKeyShutterSnap`、第二个 `miuicam_capture_event` 或第二个 JPEG。

这次窄日志已补齐此前缺失的 `onPictureTakenFinished` 证据。因此 C3 的实现边界可以明确为：保留初始 DOWN 产生的第一张照片，在长按分发达到阈值且第一张完成后，异步切换另一种 CV 并发起第二张；不得在 `onKeyUp` 直接补拍，也不得把 repeat 当作第二次拍摄。正式代码仍未修改，诊断探针也没有消费事件或改写返回值。
