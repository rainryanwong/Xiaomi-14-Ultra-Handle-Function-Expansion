# 快门长按原生连拍：下一轮按键残留根因与修复

## 观察窗口

用户反馈的重点窗口为 2026-08-31 19:04 左右，测试相机为官方
6.4.000530.0。只使用该窗口的 HandleFix 窄日志和已保存的相机反编译结果，
没有重新读取整份 logcat。

## 日志事实

- 相机进程 PID 为 16149；每一次物理快门均为 `keyCode=27`、`scanCode=212`。
- 19:04 窗口内每次 `transaction_begin` 都有新的 `downTime`，例如
  `598860 → 600868 → 601980 → 604060 → 606668 → 609268`；没有同一
  `downTime` 被下一轮复用。
- 每次 `ACTION_UP` 都在模块侧进入 `RELEASING`，随后旧实现约 1–2 ms 内记录
  `transaction_cleanup reason=after_key_up`。因此模块事务本身没有遗留到下一轮。
- 最短的一次长按结束后约 802 ms 就收到下一次 `ACTION_DOWN`；这是最接近相机
  原生释放边界的一次，和用户描述的“短时间再次按下后跳过单拍、直接连拍”一致。

## 相机原生释放链

在官方 6.4.000530.0 的真实 dex 反编译结果中：

1. `Camera2Module.onKeyUp(int, KeyEvent)` 调用
   `performKeyClicked(..., pressed=false)`。
2. 长按连拍由 `p434x3.s`（MultiCaptureManager）管理；其
   `stopMultiSnap()` 会先将 `f27596d` 清零，再通过主线程发送 `message 48`，
   由 `cameraManager.j(1)` 完成相机状态复位，延迟窗口约 800 ms。
3. 连拍完成入口为 `Camera2Module.onBurstPictureTakenFinished(boolean,long)`；
   该方法调用 `mMultiCap.e()` 后再进入统一的拍摄完成/空闲链。
4. `Camera2Module.resetStatusToIdle()` 是 quick-shot 状态机的最终空闲入口。

所以，按键日志中的“事务已清理”不等于相机已经完成原生 MultiCapture 的
busy/idle 收束。问题是两条生命周期的时序竞态，而不是旧 `downTime`、模块
Map 或配置文件被错误复用。

## 最小根因修复

`ShutterHoldBurstController` 现在维护一个按 `Camera2Module` 弱引用关联的
`ReleaseGate`：

- 只有真正跨过阈值并进入 `BURST_ACTIVE` 的事务才创建释放门；普通短按仍在
  `ACTION_UP` 后立即收口。
- `ACTION_UP` 后事务进入 `RELEASING`，不再无条件立即销毁。
- 如果释放门尚未被原生回调清除，下一次物理 `ACTION_DOWN` 建立
  `WAITING_NATIVE_RELEASE` 事务；该事务的所有决策点明确返回“单拍”，不会把
  相机原生长按判断重新接管为连拍。
- `onBurstPictureTakenFinished(boolean,long)` 和 `resetStatusToIdle()` 的精确
  Hook 只在回调返回后清除释放门；如果相机实例销毁且永远不回调，15 秒事务
  上限仅作为失效保护放行，不是功能性 cooldown。
- 释放信号在用户仍按住第二轮按键时到达，会把等待事务重新武装为
  `PRESSED_SINGLE`；后续 repeat 仍依据真实 `eventTime-downTime` 判断阈值，
  不补发 KeyEvent、不模拟触摸、不调用拍照或 `multiCapture()`。

## 构建与静态校验

- 构建门：`-PholdBurstReleaseFix=true -PholdBurstMultiTest=true`
- JDK 21：Temurin `21.0.12.1`
- APK：`outputs/Xiaomi14Ultra摄影手柄功能拓展_v12.1.01-HOLD-BURST-RELEASE-FIX-TEST.apk`
- 包名：`com.handlefix.all`
- versionName：`12.1.01-HOLD-BURST-RELEASE-FIX-TEST`
- versionCode：`1304`
- 大小：`9,494,963` bytes
- SHA-256：`B11DF3AE49330BC16C8F66E068ED3E89CDD2627D1AFFDF00BE89E225AB150545`
- APK 签名：v3 验证通过
- 内置源码资产仍只有 `assets/handlefix-src-12.0.83.zip`，没有生成新的源码快照。
- 默认无属性的 `BuildConfig` 已核对为 `12.0.97 / 1300`，所有 hold-burst
  测试门均为 `false`。
- `git diff --check` 通过。

本轮未安装、未重启、未提交、未推送；等待实机复测确认释放门在官方 530、
Phoenix、NRV 以及街拍 225 的实际回调时序均符合预期。
