# v12.1.09 / 1312 核验（2026-09-03）

## 产物

JDK21 普通 :app:assembleRelease --no-daemon 通过，含 Lint、R8。
APK：outputs/Xiaomi14Ultra摄影手柄功能拓展_v12.1.09.apk，9541501 bytes。
SHA256：E60BC9AF41FE533292C9C19BE40802347C8A04E4A8B72A78EA5AB5B039EFF8C0。
源码：outputs/handlefix-src-12.1.09.zip，3343445 bytes。
SHA256：6DBE4D18F08D42EC7357CCF11C36847A2CB829212ACCFB00CEAEA88BC9BC1C35。
包名 com.handlefix.all；versionCode1312/versionName12.1.09；v3签名通过。
84个源码文件逐字节匹配工作区；APK唯一内置源码与独立ZIP一致；API82入口保留、现代service依赖删除、无hold-burst诊断类；DEBUG/VERBOSE_HOOK_LOG=false。
手机安装base.apk的SHA256与上述APK一致。12.1.08 APK/source以及更早产物保留outputs，不清理用户资料。

## UI与相机（6ea663f2，Phoenix0.8.0/760000800）

19:52:21.573 Live probe accepted scope=android version=1312。
通过实际UI进入环境检查、模块诊断再返回，标题保持模块设置与调试，原滚动坐标保持；导入配置页返回仍为备份与恢复。未导入/恢复配置。上述返回只有一条初始Live probe，不重复启动门禁。

19:54首轮仅拦StartControl.create能进入229，但原生菜单/退出失灵。审阅U4.i.Yq发现原生q.c0(mode)在factory之前，已删除factory拦截，改为精确Yq(ILjava/lang/String;Z)Z输入处选229，由原生统一保存模式/创建模块。没有额外退出Hook。

20:01:03.421 最终代码相机进程25139，hook summary ok=13 fail=0。
20:01:34.266 正常相机UI选择街拍记录225->229；20:01:34.631 EquipStreetModule预览mid229。
20:01:39.643 点击原生退出产生0xe5->0xe1；20:01:39.925 StreetModule预览mid225，普通模式列表恢复。
20:02:04.300、20:02:11.227 再次选择街拍进入特别款；MENU打开时UI树显示闪光灯、运动抓拍、画幅、水印、快门样式、设置等。未按快门，未更改急速相机设置，未使用拍照启动Intent。窄AndroidRuntime错误窗口未见崩溃。
菜单内设置跳转未独立完成可靠核验，不将其列为已测；正常拍照及所有手柄动作未重新做实拍回归。

0.3.0/0.8.0两份原始DEX共同确认U4.i.Yq、w.d、Q5.J.d精确参数/返回类型。0.3.0本轮仅静态核验，没有重新刷相机实测。
父/子开关关闭、原生开关关闭的负向路径经代码审计，本轮未变更用户配置实机全矩阵验证。

最终文档补齐后重新打包安装，功能DEX未再改动；最终重启及Git远端结果见STATUS.md。
