# Prometheus Camera V5.1 模块样本适配报告

日期：2026-09-02（Asia/Shanghai）

## 样本身份

- 用户样本：`D:\Camera Files\Prometheus_Module_V5.1_AllInOne.zip`
- ZIP 大小：`272223045` bytes
- ZIP SHA-256：`CCCCB50F81A6FEDB6E324EB70BB8DA36E144FE5FE7DB623B59F7F69D44D9B842`
- `module.prop`：
  - `id=legend17u_14u_local`
  - `name=Prometheus Camera V5.1 - Xiaomi 14 Ultra`
  - `version=V5.1`
  - `versionCode=500100`
- ZIP 内 APK：`Prometheus_Cam_V5.1.apk`
- APK 条目大小：`231100245` bytes
- APK SHA-256：`C8EDD11DBB77A4B19267C64DEC668CE5C708569436DF0F1406D6D93D923BB587`
- APK 静态元数据：package=`com.android.camera`，versionName=`V5.0`，versionCode=`750005100`

## 与旧 V5.1 提取样本的区别

| 样本 | module/APK 版本标识 | 长按链结论 | 本轮处理 |
| --- | --- | --- | --- |
| 模块发行版 V5.1（本轮） | `module.prop`=`500100`；APK=`750005100` | 现代 `KeyEvent` 链 | 精确纳入并进行完整 descriptor 预检 |
| OS1 5.1.001130.2 提取样本（旧） | APK=`510011302` | 旧式 repeatCount 链，不是本轮现代链 | 保留常量但明确不支持，不伪造适配 |

两者不能因名称都为 V5.1 而合并。`CameraBuilds.PROMETHEUS_V51_VERSION_CODE`
继续表示旧的 `510011302L` 提取样本；模块发行版使用新增的
`PROMETHEUS_MODULE_V51_VERSION_CODE=750005100L`。

## 真实现代链

真实 APK 的 raw JADX（rename none）确认 `Camera2Module` 具有以下入口：

```text
onKeyDown(int, KeyEvent): boolean
onKeyUp(int, KeyEvent): boolean
performKeyClicked(int, String, KeyEvent, boolean): void
isNeedBurst(int, KeyEvent): boolean
static lambda$performMiHandlePressed$49(KeyEvent, f4.K): Boolean
startNormalCapture(int): boolean
onBurstPictureTakenFinished(boolean, long): void
resetStatusToIdle(): void
```

其中 `$49` 的真实逻辑为 `!K.r4(event)`；`performMiHandlePressed` 根据该 lambda
决定是否走 `doKeyShutterLongPress`，而 `repeatCount=0` 走
`doKeyShutterSnap`。这与旧 `510011302` repeatCount-only 样本的边界不同。

## 适配边界

- 只有 `prometheusProfile=true` 且相机 `versionCode==750005100L` 时，
  `ShutterHoldBurstController` 才启用本样本的完整现代链预检。
- 在安装任何 Controller Hook 前，必须同时精确匹配上述
  `onKeyDown`、`onKeyUp`、完整 `performKeyClicked`、`isNeedBurst`、唯一的
  `static Boolean(KeyEvent, interface)` `$49`、`startNormalCapture(I)Z`、
  `onBurstPictureTakenFinished` 和 `resetStatusToIdle`；任一缺失或歧义都会
  记录 `install aborted` 并 fail closed。
- 通过预检后仍沿用现有 `$49` 决策 Hook、首张 `startNormalCapture` 接受门和
  `ReleaseGate`；不主动调用拍照/连拍，不改变输入事件、UI、功能码、C3 或其它
  Phoenix/NRV/官方版本的 lambda 选择。
- 旧 `510011302L` 不满足现代长按候选门，不会因同名 V5.1 获得本适配。

本报告只记录样本与结构适配；没有把 ZIP 内约 231 MB 的 APK 复制到仓库。
