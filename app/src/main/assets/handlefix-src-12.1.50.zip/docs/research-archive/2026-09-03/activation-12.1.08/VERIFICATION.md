# 12.1.08 实机交付核验（2026-09-03）

设备：6ea663f2 / 24031PN0DC，小米14Ultra。
版本：com.handlefix.all 12.1.08 / 1311。

- JDK21 完整 assembleRelease 成功，包含 Lint/R8/资源压缩。BuildConfig.DEBUG=false；VERBOSE_HOOK_LOG=false。
- v3 签名通过，保留原签名；源码83文件逐字节等于工作区，APK只含handlefix-src-12.1.08.zip，传统xposed_init保持原样，现代service依赖已移除。
- 首次安装、重启前：08:17:15.109 Live probe unconfirmed；UI hierarchy真实显示未确认提示和继续进入设置/重新检测按钮。
- 首次重启暴露系统init参数顺序差异，未把它作为完成交付；直接读取本机services.jar真实DEX：init(Context,WindowManagerFuncs,IWindowManager)V，补上精确描述符后重新构建、更新源码、覆盖安装和重启。
- 最终重启：sys.boot_completed=1，su id=uid=0(root)。
- 08:22:54.873 SystemHandleFix: installed in system_server。
- 08:22:58.221 [HandleFixActivation] live probe registered scope=android version=1311。
- 08:23:27.466 HandleFixActivation: Live probe accepted scope=android version=1311。
- UI hierarchy核验设置页面及主页均可进入；主页包含启用模块功能、手柄按键映射方案、快门/变焦/拨轮/录像配置等。未出现等待门禁阻塞。
- 临时手机层级文件 /data/local/tmp/handlefix-activation-1311.xml 已删除，未在公共目录留下诊断文件。
- 未修改LSP作用域/开关、相机配置、用户按键映射；未提交/推送GitHub。只切换了UI的主页导航以核验。

最终APK：outputs/Xiaomi14Ultra摄影手柄功能拓展_v12.1.08.apk，9538751字节。
SHA256：83CD6B6534E915ED9563BEFAE8CBC8D3CEB0720F5AD51D3B96EA560F242AA7E0。
源码：outputs/handlefix-src-12.1.08.zip，3340546字节。
SHA256：AA5DDFC310AD6BD80064BEC5934A96B846CC4DEEC89E60A17A83907CDFFCBD84。

边界：未为了测试而关闭用户LSP模块；禁用后重启、只有相机作用域、不同ROM的全矩阵尚未实测。本轮相机独立探测只静态核验，成功实机证据来自系统作用域。无手柄街拍等相机功能不在本轮验收范围。
