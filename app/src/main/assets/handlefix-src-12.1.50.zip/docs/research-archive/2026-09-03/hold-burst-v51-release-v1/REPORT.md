# HandleFix 12.1.06 长按高速连拍正式化报告

更新时间：2026-09-03（Asia/Shanghai）

## 当前目标

把已在官方相机与 Prometheus Cam 多版本验证的快门长按原生高速连拍整理为正式实现，
修复 V5.1 与 Phoenix-0.7.23 在上一轮松手后再次长按时无响应或只拍单张的问题，并完成
界面、配置、说明、源码快照和发布构建。

## 已确认的事实

- 正确的 V5.1 样本内嵌相机为 `com.android.camera`、`V5.0`、`versionCode=750005100`，
  使用现代 `KeyEvent` 链与 `$49` 连拍决策入口。
- 23:42 后的窄日志显示：上一轮释放尚在原生收口时，旧 `ReleaseGate` 会把新
  `ACTION_DOWN` 建成等待事务；等待结束后只能重新武装模块状态，已经丢失的真实 DOWN
  无法重放，因此本轮可能完全无响应或只完成首张单拍。
- 每轮 `startNormalCapture(I)Z` 的真实返回值已经足以证明本次首拍是否被相机接受；
  在它返回 `true` 前，长按 repeat 不应进入原生连拍。

## 根因修复

- 删除跨手势 `ReleaseGate`、`WAITING_NATIVE_RELEASE`、释放完成/idle 诊断 Hook 和相关
  测试构建开关。
- 每个真实 `ACTION_DOWN/repeat=0` 都清理旧模块事务，并为本次物理手势独立建立
  `PRESSED_SINGLE`。
- 只有当前事务的 `startNormalCapture(I)Z=true` 且真实 repeat 达到用户阈值，才进入
  `BURST_ACTIVE` 并在精确的原生决策点返回 `true`。
- `ACTION_UP` 仍由相机自己的 onKeyUp/停止链完成；模块只标记释放并清理本地事务。
- 未使用伪造 KeyEvent、触摸注入、定时循环、主动拍照、直接 multiCapture 或相机偏好写入。

## 配置与界面

- 快门长按阈值统一为 500–1000ms，读取和导入旧配置时均做边界归一化。
- 功能名为“徕卡经典/生动轮拍”和“高速连拍”；弹窗标题改为“长按·选择…的功能”。
- 底栏顺序为“主页－模块设置与调试－备份与恢复”。
- 街拍特别款移至半按对焦策略下方；开发者选项、显示模式编号、环境检查和模块诊断同组。
- 旧版 Prometheus Cam 适配开关只在精确检测到 750005100 时显示和运行，隐藏时保留配置。
- 备份继续复制完整 JSON 根对象，覆盖快门长按动作与 `shutterLongPressMs` 等全部配置。

## 构建与产物

- JDK：`D:\\DevTools\\jdks\\jdk-21.0.12.1+1`
- 构建：`:app:assembleRelease --no-daemon`
- 版本：`12.1.06 (1309)`
- 包名：`com.handlefix.all`
- APK：`outputs/Xiaomi14Ultra摄影手柄功能拓展_v12.1.06.apk`
- APK SHA-256：`F565EBBE310388674D2C75561D4321295BC75F4EA011C193E4790C85FFA2AED1`
- 内置源码：`app/src/main/assets/handlefix-src-12.1.06.zip`
- 源码 ZIP SHA-256：`D5CAE1A06D9C96922E3CB7CDC2CC697E7396A50FB26894B7DAA72D45850582B4`
- APK Signature Scheme v3：通过。

## 部署验证

- 提交：`57788f0c4b27239a4517c8e138c09f420aebd3a2`，已推送 `origin/master`。
- 设备：`6ea663f2` / `24031PN0DC`，安装成功并完成重启。
- 开机状态：`sys.boot_completed=1`；KernelSU Root：`uid=0`。
- 已安装模块：`12.1.06 (1309)`；当前相机：`V5.0 (750005100)`。
- LSPosed：`ShutterHoldBurstController` 精确挂载 6 个方法；模块汇总 `ok=25 fail=0`；
  未发现 FATAL、连拍控制器安装中止或 Hook 失败。

## 仍需用户验证

- 安装与重启后确认 LSPosed 相机进程加载 12.1.06 的正式控制器。
- 普通拍照和街拍分别验证：单次短按、长按连拍、松手停止、快速再次长按、等待后再次长按。
- 构建/签名通过不等同于真机拍摄验收；最终行为以用户实测为准。

## 不能改变的约束

- 原生连拍只开放给已确认能力的拍照 163 与街拍 225。
- 相机包、版本/版本组、真实 descriptor、映射 Profile 和模式必须同时通过能力门。
- C3 轮拍与高速连拍保持互斥且不共享状态机。
- 未验证版本 fail closed，不通过异常吞噬或补丁叠加强行接管。
