# Phoenix-0.7.23 长按原生高速连拍候选核对

更新时间：2026-09-01（Asia/Shanghai）

## 样本

- 来源包：`D:\Camera Files\Phoenix_Phoenix-0.7.23-uncompressed_AllInOne.zip`
- 相机 APK：`Phoenix_Camera_Phoenix-0.7.23.apk`
- 包名：`com.android.camera`
- versionName：`Phoenix-0.7.23`
- versionCode：`760000723`
- SHA-256：`F349F54D9EF8B1CF3BACA0212FDE0B3D32602D16E50BB425AB3F3AF97F2497B7`
- 基线：与 Phoenix-0.3.0 同属 OS4 6.6.000510.0 适配链；0.3.0 的相机 versionCode 为 `760000300`。

## 真实 descriptor 证据

使用解包后的 `classes.dex` 和实际类加载结果核对，0.7.23 保留以下原生生命周期：

```text
Camera2Module.lambda$performMiHandlePressed$50(KeyEvent, Q6.L): Boolean
Camera2Module.isNeedBurst(int, KeyEvent): boolean
Camera2Module.onBurstPictureTakenFinished(boolean, long): void
Camera2Module.resetStatusToIdle(): void
```

其中 `$50` 决策链与已实测的 Phoenix-0.3.0 相同：返回 `true` 进入相机原生长按连拍路由，返回 `false` 保持单张路由；连拍停止和最终 idle 仍由相机自身生命周期收口。

## 门限策略

`CameraBuilds.isPhoenixHoldBurstSupported()` 不再只比较 0.3.0，而是识别 `76xxxxxxx` Phoenix OS4 家族。候选进入 `ShutterHoldBurstController` 后仍必须通过上面四个真实 descriptor 的运行时完整核对；任一 descriptor 缺失时直接 fail-closed，保留原生行为，不显示/挂载一个猜测的入口。

这使后续仍沿用 6.6.000510.0 底包、版本号继续位于 `76xxxxxxx` 的 Phoenix 包可以自动进入同一候选路径，同时不会把版本号门误当作能力证明。街拍特别款等独立协议仍然保留自己的精确版本门。

## 本轮测试包

- 构建版本：`12.1.02-HOLD-BURST-PHOENIX-0723-TEST`
- versionCode：`1305`
- APK：`outputs/Xiaomi14Ultra摄影手柄功能拓展_v12.1.02-HOLD-BURST-PHOENIX-0723-TEST.apk`
- SHA-256：`228C1DC31B27A626943F92E791E4D315C73183AE7D43B39D0E1C995410C0088F`

本包仅用于 Phoenix-0.7.23 实机验证；没有安装、重启、提交或推送，也没有更新正式更新日志和内置源码快照。
