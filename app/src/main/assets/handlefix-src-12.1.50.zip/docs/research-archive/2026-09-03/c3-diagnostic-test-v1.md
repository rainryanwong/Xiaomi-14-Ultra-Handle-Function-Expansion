# C3 诊断包测试步骤

诊断包：`outputs/Xiaomi14Ultra摄影手柄功能拓展_v12.0.83-C3-DIAG.apk`
内部 versionCode：1286；显示 versionName 仍为 12.0.83；C3 功能本身仍未启用。

## 测试前

1. 仅在已确认的测试设备上安装诊断包并重启，使 LSPosed 重新加载相机进程。
2. 保持 HandleFix 和对应相机作用域开启；不需要打开“双风格拍摄”，也不要修改现有按键映射。
3. 关闭连续拍摄等会改变一次按键对应拍摄次数的实验选项。

## 每个版本的最小操作

先只测试普通拍照模式（moduleId=163）：

1. 打开相机并进入普通拍照模式。
2. 等待预览稳定后，使用手柄快门键完成一次普通拍照。
3. 间隔 2 秒再拍一张，重复 2–3 次。
4. 不要在同一轮中切换 HDR、夜景、参数预设或连拍；这些场景留待第一轮确认后再测。

建议优先测试 Phoenix-0.3.0，之后再测 NRV1.6.1、官方 6.4.000370/530 和 OS4 6.6.000510。

## 需要提供的日志

导出相机进程和 LSPosed 日志中包含 `[HandleFix] c3diag` 的完整片段。不要只截取最后一行，至少保留一次拍照前后约 5 秒内容。

关键行包括：

- `event=key_down` / `event=key_up`：确认 27/170 的按键边界；
- `event=performKeyClicked` / `event=doKeyShutterSnap`：确认手柄快门是否进入原生拍摄链；
- `event=startNormalCapture.before/after`：确认原生拍摄入口是否接受请求；
- `event=onCaptureCompleted`：记录管线完成次数；
- `event=onPictureTakenFinished`：记录最终完成回调的 `success/timestamp/type` 和 CV 状态；
- `signature ...`：确认运行时实际 descriptor。

## 判定标准

普通拍照的一次有效快门，理想日志顺序为：

```text
key_down → performKeyClicked/doKeyShutterSnap → startNormalCapture.after(result=true)
→ onCaptureCompleted(可能一次或多次) → onPictureTakenFinished(success=true，一次)
```

如果一次快门出现多个成功的 `onPictureTakenFinished`，需要先分析 `timestamp/type` 和
调用来源，不能直接接入第二次拍摄。诊断探针不会改变按键、照片数量或徕卡风格。
