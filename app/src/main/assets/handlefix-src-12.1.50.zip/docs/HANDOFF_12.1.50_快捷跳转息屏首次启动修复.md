# HandleFix 12.1.50：快捷跳转息屏首次启动修复

## 发布范围

- 保持 12.1.49“相机模式快捷跳转”的入口、模式列表、临时 Phoenix 能力门和更新日志正文不变。
- 修复相机曾经运行并留有后台任务时，息屏或锁屏状态首次长拨只有振动、需要再次长拨才能显示目标模式的问题。
- 修复应用于长拨变焦拨杆列表中的全部有效目标；“保持原生（不响应）”不进入快捷启动链。

## 根因与修复

- 旧 Camera Activity/任务会让 Phoenix 在息屏启动时复用不稳定的模式初始化状态；把 `FLAG_ACTIVITY_CLEAR_TASK` 叠在新启动 Intent 上，也可能只完成清栈而没有留下可见 Activity。
- system_server 在发起目标模式 Intent 前，先查询并移除现有 `com.android.camera` 任务，再发送一次不带 `FLAG_ACTIVITY_CLEAR_TASK` 的普通启动请求。
- 设备框架实际任务接口是 `ActivityTaskManager.getInstance().removeTask(int)`，不是 `ActivityManager.removeTask(int)`；后者在第一版测试包中触发 `NoSuchMethodException`，已按设备 `framework.jar` 的真实签名修正。
- 查询或任务移除失败时保持 fail closed，不发送启动请求，也不提供成功振动；不使用固定延时、双 Intent、模拟触摸或伪造按键。

## 验证边界

- 普通街拍 225、街拍特别款 229、街拍传奇款 229 已由用户确认：息屏状态首次长拨即可进入，三种目标均不再需要第二次操作。
- 用户随后逐项测试其它快捷目标，确认它们存在相同首次启动现象，因此 12.1.50 将同一根因修复统一扩展到列表内全部有效目标。
- 全列表扩展已经完成静态调用顺序、Release 编译和包体结构验证；最终设备验收仍以 12.1.50 安装后的逐模式复测为准。

## 发布约束

- `HandleFixModule.VERBOSE_HOOK_LOG` 与 `SystemHandleFix.VERBOSE_INPUT_LOG` 保持关闭。
- 12.1.50 更新日志正文沿用 12.1.49 已确认文案，只同步显示版本号。
- 当前快捷跳转 UI 仍仅对 Prometheus Cam 映射与 Phoenix 版本组组合开放；其它相机族入口继续置灰。
