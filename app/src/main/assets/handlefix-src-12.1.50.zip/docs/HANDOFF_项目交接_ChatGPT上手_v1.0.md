# HANDOFF — 项目交接 / ChatGPT 上手指南（v1.0）

> 目标读者：接手本项目的新模型（如 ChatGPT/Claude）或新人开发者。
> 项目：**摄影手柄功能拓展（HandleFix）** —— 小米 14 Ultra 专业摄影手柄的 LSPosed 模块。
> 当前版本：**v12.1.09**；仓库：`https://github.com/rainryanwong/handlefix-module`（私有）。

---

## 1. 项目一句话

用 Xposed/LSPosed 给小米 14 Ultra 摄影手柄做功能拓展：按相机模式自定义
录像键/快门键/自定义拨轮/变焦拨杆，支持录像键长按预览照片；同时适配
**Prometheus Cam 移植相机** 和 **官方相机（HyperOS 3 / HyperOS 4）**。

## 2. 先读什么（按顺序）

1. 仓库根 `README.md` —— 适配范围 / 构建 / 结构 / 约定
2. `OemHooks.java` 顶部注释 —— **OS4 相机混淆类名对照表**（460/510 双候选，重要）
3. `HandleFixModule.java` —— 入口：版本判定 + 按 promFix 分发安装
4. `ModeConfig.java` —— 配置体系（JSON）+ 开关/过滤表
5. 本文档 3~8 节

## 3. 架构速览

```
HandleFixModule.handleLoadPackage(com.android.camera)
 ├─ Phoenix OS4 版本族 / 当前样本 Phoenix-0.3.0（760000300，6.6.510 基线，优先识别）
 │   └─ OemHooks.installPhoenixOs4()：复用 OS4 底层映射，仅夜景 169 注册 EV 面板补偿
 ├─ promFix=开（其他 PrometheusCam）
 │   ├─ V5.1 开关开（旧包）→ PromHooks + LeicaHooks（基础修复补丁）
 │   └─ V5.1 开关关（NRV 新包）→ 跳过共有补丁，仅独有功能 + NRV 门槛
 ├─ promFix=关（官方相机）→ OemHooks（按键映射 / 快门决策 / OS4 EV 显示）
 └─ promFix=开 + streetSpecial=开（Phoenix OS4 版本族 + 原生结构）→ StreetSpecialHooks
      ├─ 0.3.0/0.8.0：核对 Je.c.M()Z、原生设置方法、229 入口和继承链后放行能力门
      └─ streetSpecialWithoutGrip=开：手柄工厂 p6.b.g 调用范围内覆盖指定 Global 读取

system_server（系统框架作用域）
 └─ SystemHandleFix → GlobalRecordVideoHook
      ├─ 仅跳转：标准 VIDEO_CAMERA Intent
      └─ 跳转并录制：私有一次性标记 → QuickVideoLaunchHooks → VideoModule 原生 gate
```

- **promFix**：主界面「启用"Prometheus Cam"手柄映射」开关。
- **V5.1 开关**：「旧版"Prometheus Cam"手柄适配」，仅 promFix=开 时可调，且随 promFix 联动置灰。
- **主界面总开关**：「启用模块功能」。
- **streetSpecial**：模块设置与调试页「启用街拍特别款」；Prometheus 方案、Phoenix 同一 OS4 版本组候选。运行时检查真实 229 特征，不再精确锁定 0.3.0。
- **streetSpecialWithoutGrip**：依赖父开关，相机内手柄工厂读取作用域使用虚拟连接值；正常街拍选择在原生 U4.i.Yq(225,String,boolean) 输入处根据原生设置及首用引导完成状态选择229，由原生同步存储模式和StartControl，不能只改工厂最终模块。保留原生退出路径，不修改急速相机设置或拍摄动作。父开关关闭、切官方方案、恢复默认时清除，导入也做依赖清洗。
- **启用检测**：API82实时探测和独立Scaffold失败提示；12.1.09移除返回页面时反复检测/销毁MainScreen的行为，已进入界面后不重复门禁。不要把resumeTick重新接回检测；它仅负责配置刷新。详见 `HANDOFF_12.1.09_页面返回与街拍入口.md`。

### 关键文件职责

| 文件 | 职责 |
|---|---|
| HandleFixModule.java | LSPosed 入口、版本探测、install 注册表、Phoenix/Profile/promFix/V5.1 判定 |
| CameraBuilds.java | 统一读取 `ApplicationInfo` versionCode、Phoenix OS4 版本族与精确版本门 |
| ModeConfig.java | 配置 JSON 读写、过滤表、开关状态、模式/功能码 |
| CameraCapabilityRegistry.java | 集中维护已验证版本能力；未确认入口不显示、不强行挂载 |
| RecordLongPressDispatcher.java | 录像键短长按/深长按松键分段的唯一入口 |
| LeicaStateAdapter.java | 只读取徕卡经典/生动二态，不与作者多 LUT 风格混用 |
| ClassicStyleController.java | Phoenix/NRV 作者多 LUT 目录、选择白名单和真实 Store API |
| FocusPolicyHooks.java | 摄影手柄半按对焦原生/禁用/中心单次 AF |
| QuickVideoLaunchHooks.java | 把外部快捷录像一次性请求接回相机 VideoModule 原生 gate |
| PromHooks.java | PrometheusCam 老包共有补丁（fix1-5、S0、设置页） |
| LegacyParamPanelHooks.java | V5.1/NRV 旧链专业拍照录像键参数预设；复用 K3.u1.i0 原生工作区入口 |
| PhoenixWheelHooks.java | Phoenix OS4 版本族专业拍照波轮 J 到 q6.U0.S0 的兼容映射 |
| LeicaHooks.java | 徕卡经典/生动切换 + 手柄设置页注入 |
| ModeAwareHooks.java | 模式感知按键映射（独有）+ NRV 门槛放行 |
| ZoomHooks.java | 变焦拨杆 / 快门连拍 / 焦段（独有） |
| OemHooks.java | 官方 / Phoenix OS4 Profile 映射、快门单张/连拍；官方全量、Phoenix 夜景 169 安装 OS4 EV 条补偿（含混淆映射表） |
| EnvHooks.java | 版本探测、环境记录（相机外部目录）、模式缓存 |
| StreetSpecialHooks.java | Phoenix OS4 版本族 + StreetSpecialProfile 原生结构校验后 hook `Je.c.M()Z` |
| system/SystemHandleFix.java | 系统层按键透传入口 |
| system/GlobalRecordVideoHook.java | 任意界面长按录像键、500–1000ms 阈值与 VIDEO_CAMERA 启动 |
| ui/*.kt | Miuix Compose UI（主页/按键配置/环境检查/模块诊断/备份恢复） |

### Phoenix OS4 版本族：OS4 映射 Profile、参数预设与街拍特别款（v12.0.50 起）

- 目标：Phoenix-0.3.0，实际 `versionCode=760000300`。不要采用文档/更新日志中曾出现的
  `750005500`，那是其他 NRV 包的旧版本号。
- 根因：`Je.c.M(): boolean` 是机型能力门。14 Ultra 的 ROM 配置为 false，因而特别款
  moduleId 229 虽在 APK 内却不会注册，手柄设置页也不会出现对应复选框。
- 正式方案：只替换 `Je.c.M()` 为 true。`w.d()` 与
  `EquipStreetModuleEntry.support()` 已调用 M()，且前者还要读取相机原生偏好
  `pref_camera_handle_equip_street`；不要把它们强制为 true，否则会绕过用户在相机设置页的开关。
- 保持原生边界：不伪造 IMiCharge 手柄在线状态，不把 229 放入底部模式列表；真实手柄、快速启动、
  前台插拔切换和 229 原生禁用高速连拍的行为均由相机处理。
- 相机进程加载阶段不能依赖 `currentApplication()` / PackageManager 取版本；从
  `loadPackageParam.appInfo` 读取 `longVersionCode`，失败时才回退 `versionCode`。
- 主界面使用时应选择「Prometheus Cam」方案，街拍特别款选项才会显示；运行时会优先按
  Phoenix OS4 版本族（当前样本 `760000300`）识别，以防旧配置误选官方方案后把官方
  直读链或非目标 EV 补偿装进 Phoenix。
- 映射分流必须保持为**安装时 Profile**：`OemHooks.install()` 是官方 Profile，会注册
  `q6.g1.Ud` / `q6.U0.G1` 的 EV 面板补偿；`OemHooks.installPhoenixOs4()` 复用同一协议，
  但只对 Phoenix 夜景 moduleId=169 启用，普通/专业等已有原生面板的模式不重复展开。
  Phoenix 仍跳过官方 `data.r/s.c/e` 直读链，以免重现设置页返回值类型崩溃；不要改回每次
  拨轮回调里根据 `promFix` no-op 的旧写法。
- Phoenix 不能叠加 `ModeAwareHooks` / `ZoomHooks` 的普通 Prometheus 链，它们依赖 NRV/V5 的
  特有类与事件责任链。作者 LSP 的多 LUT 风格动作例外：同一 OS4 版本组可先尝试，
  运行时还必须通过 `ClassicStyleStore` 方法签名检查；NRV 仍只开放 1.6.1。街拍特别款和
  其它精确 dex 入口仍需先反查 APK，再扩展 `CameraBuilds` 的精确版本门。

### 专业模式参数预设：录像键与波轮入口（v12.0.50 起）

- 过滤规则在已验证的 Prometheus Cam 版本，以及官方 6.4.000370.0、6.4.000530.0、
  6.6.000510.0 的**录像键 → 短按 / 自定义拨轮 → 专业拍照（167）**中显示
  「专业模式参数预设（新）」；其它官方版本由能力门隐藏，开发者模式也不会绕过物理兼容性门。
- V5.1/NRV 旧链由 `LegacyParamPanelHooks` 复用 `K3.u1.i0(MotionEvent, boolean, String)` 的
  `attr_workspace` 原生入口；`h1` 仅负责延迟统计，不能拿来代替打开面板。再次按键时交给
  `FragmentManualWorkspaceBottom.onBackEvent(4)` 做原生关闭和状态清理。
- Phoenix-0.3.0 由 `PhoenixWheelHooks` 复用 `q6.U0.S0`，录像键关闭逻辑仍由
  `PhoenixClassicStyleHooks` 捕获 `T9.A` Fragment 后调用原生 `onBackEvent(4)`；不能把两条
  混淆类链交叉挂载到官方相机或另一套移植包。

## 4. 构建与产物

```powershell
$env:JAVA_HOME = "D:\DevTools\jdks\jdk-21.0.12.1+1"
.\gradlew.bat :app:assembleRelease
```
- 产物：`app/build/outputs/apk/release/app-release.apk`
- 或 `powershell -ExecutionPolicy Bypass -File build.ps1`（复制到 outputs 并按版本命名）
- 技术栈：AGP 9.3.1（内置 Kotlin）、Kotlin 2.4.10、Compose Multiplatform 1.11.1、miuix 0.9.3、compileSdk 37 / minSdk 33 / targetSdk 34
- **坑**：不要往 app/build.gradle.kts 重复加 `org.jetbrains.kotlin.android` 插件；LSPosed 依赖 `assets/xposed_init` + metadata，别动。
- **性能约定**：按键/拨轮热路径只读 `ModeConfig` 的 200ms 配置快照；不要恢复逐事件文件解析或无条件逐事件日志。跨进程保存配置必须使用同目录临时文件再原子替换。

## 5. 工作流约定（务必遵守）

1. **git 推送**：只在用户明确说“推送”时 `git push`；平时改完只 `git commit` 留本地。
2. **版本号**：12.0.x 小版本迭代；默认**逢百进位**（12.0.100 → 12.1.0）；用户指定才直接进位。
3. **更新日志 / 源码 zip**：只在用户明确要求时更新。
   - 更新日志：`ui/ModuleTexts.kt` 的 `CHANGELOG_TEXT`（只写当前版本）
   - 源码 zip：`app/src/main/assets/handlefix-src-<version>.zip`（文件清单参照旧 zip）
4. **修复原则**：按根因做**最小改动**，禁止补丁叠叠乐；新代码补注释（目的 + 原理）。
5. **相机类名**：官方相机混淆类名以 `OemHooks.java` 顶部映射表 + dex 方法级反查为准；
   **不要照抄 jadx 显示名**（大小写冲突会改名，如 `Q6.i0` 显示成 InterfaceC1894i0、`q6.g1` 显示成 p563q6.g1）。
6. **双版本候选**：OS4 460/510 混淆不同，hook 类名用“候选数组”同时适配。

## 6. 常见调试流程

1. 模块内「模块设置与调试 → 模块诊断」看 hook 是否加载进相机进程。
2. logcat 过滤 `HandleFix`：`adb logcat -s LSPosedFramework` 或 `adb logcat | findstr HandleFix`。
3. 环境检查：系统/相机/模块版本、Root、手柄连接、手柄电量。
4. 换新相机版本时：先 `adb shell pm path com.android.camera` 拉**实际安装包**（不要用商店同版本），
   全量反编译后用 dex 方法级反查（按 log tag 字符串定位引用类）核对真实类名。

## 7. 给 ChatGPT 的提示词（可直接复制）

```
你现在接手维护一个安卓 LSPosed 模块项目「摄影手柄功能拓展（HandleFix）」，
为小米 14 Ultra 专业摄影手柄提供按键功能拓展（录像键/快门键/自定义拨轮/变焦拨杆
按相机模式自定义，录像键长按预览照片），同时适配 Prometheus Cam 移植相机与官方相机
（HyperOS 3 的 6.4.000370.0/6.4.000530.0 和 HyperOS 4 的 6.6.000510.0）。

项目位置：
- 本地：C:\Users\Ryan\Documents\Codex\2026-08-01\new-chat\work\ui_rewrite
- GitHub（私有）：https://github.com/rainryanwong/handlefix-module
- 当前版本 v12.1.09，包名 com.handlefix.all

请先按顺序阅读这些文件再动手：
1. README.md（项目根）
2. app/src/main/java/com/handlefix/OemHooks.java 顶部注释（OS4 相机混淆类名对照表）
3. app/src/main/java/com/handlefix/HandleFixModule.java（入口与分发）
4. app/src/main/java/com/handlefix/ModeConfig.java（配置体系）
5. docs/HANDOFF_项目交接_ChatGPT上手_v1.0.md（本文档）

关键约定（必须遵守）：
- 构建：$env:JAVA_HOME="D:\DevTools\jdks\jdk-21.0.12.1+1"; .\gradlew.bat :app:assembleRelease
- git 只在用户明确说“推送”时才 push，平时改完只 commit；
- 版本号 12.0.x 迭代，默认逢百进位；更新日志（ui/ModuleTexts.kt 的 CHANGELOG_TEXT）和
  源码 zip（app/src/main/assets/handlefix-src-<version>.zip）只在用户要求时更新；
- 修复按根因做最小改动，不要补丁叠叠乐；新代码补注释（写清目的和原理）；
- 官方相机类名以 OemHooks 顶部映射表 + dex 反查为准，不要照抄 jadx 显示名（大小写冲突会改名）；
- OS4 460/510 混淆不同，hook 类名用双候选数组适配。

请先概述你对项目的理解和下一步打算，再等我给出具体任务。
```

## 8. 常用信息速查

- 模块开关：主界面「启用模块功能」总开关；「启用"Prometheus Cam"手柄映射」= promFix；
  「旧版"Prometheus Cam"手柄适配」= V5.1 开关；「启用街拍特别款」= streetSpecial
  （仅 promFix=开时显示；当前街拍特别款精确适配 Phoenix-0.3.0/760000300，保留原生手柄检测和相机设置开关）。
- LSPosed 作用域：[相机] + [系统框架]；模块更新后必须重启。
- OS4 EV 条机制：左侧小 EV 值 = EvTipView（值取 ManuallyValueChangeImpl.Ud 的字符串）；
  右侧 EV 条 = FragmentManuallyExtra 面板（FeatureUI Q6.i0 状态位 (7,254)）。官方 Profile
  普通模式走 Ud 展开、专业模式走 KeyEventImpl.G1 pre-show；Phoenix 只在夜景 moduleId=169
  走同一套 Ud/G1 展开，其他模式保持作者原生 UI。
- 完整开发/修复经验：`outputs/HANDOFF_模块开发挂载修复经验全流程_v7.8.md`。
