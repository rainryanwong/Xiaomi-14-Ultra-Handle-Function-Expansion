# 12.1.48 Phoenix 街拍与分类输入保护

## 发布边界

12.1.48 合入 12.1.42–12.1.47 测试线中已经实机验收的调整。正式版关闭
`HandleFixModule.VERBOSE_HOOK_LOG` 与 `SystemHandleFix.VERBOSE_INPUT_LOG`；保留 Hook
安装结果、能力预检失败和运行异常日志，便于后续维护。

## Phoenix 传奇街拍 229

- `StreetSpecialHooks.enableConfigAliasIfSupported()` 只在 Phoenix OS4 版本族和
  `StreetSpecialProfile.preflight()` 同时通过时开启别名。
- 229 是普通街拍 225 的手柄 UI 变体，因此四类按键读取 225 的现有配置；模块不强开
  `Je.c.M()`，不绕过相机自己的模式门控。
- 徕卡经典风格提示在 229 下挂到 Activity `DecorView` 顶层，以避开 EquipStreet 后加的
  同级遮挡层；Overlay 不接收触摸，离开页面时由生命周期 Hook 清理。
- 229 底包不支持高速连拍和录像键画幅比例，配置页只增加“仅普通街拍生效”提示，不强行
  开放底包能力。

## Phoenix 徕卡一瞬 256

仅在 Prometheus Cam 映射且相机版本属于 Phoenix OS4 版本族时显示。四类按键及录像键
短长按/深长按分别使用独立过滤表；切换官方相机映射后隐藏。该逻辑只控制配置候选项，
不会绕过运行时安全门。

## 锁屏/息屏输入保护

- 总开关入口位于主页，详情进入 `GripInputGuardActivity` 独立设置页。
- 生效场景可选：锁屏和息屏、仅锁屏、仅息屏。
- 输入掩码可多选：快门（含半按）、变焦拨杆、拨轮、录像键；全选时 UI 显示为
  “全按键不响应”并禁用四个分类项。
- KeyEvent 与拨轮 MotionEvent 共用 `GripInputGuard` 的状态和掩码判断。仅屏蔽已确认的
  N1G 输入；设备身份或系统状态读取失败时放行，不解绑 USB，也不改充电状态。

## 设置页维护说明

- 摄影手柄充电控制位于手机/手柄电量卡下方。关闭供电时只收起保护选项，不改写
  `sec_setting_handle_charge_protect` 的原值；重新开启供电后恢复显示。
- Phoenix 上游已提供街拍样式自定义，模块暂时隐藏两个旧的街拍特别款开关；对应配置键、
  Hook 和备份兼容能力保留，不得仅因 UI 隐藏而删除。
- 首页按键副标题按短按、长按、短长按和深长按分类统计，不把全局默认键或结构节点计为
  自定义条目。

## 后续修改注意

适配新的 Phoenix 或官方相机版本时，应重新核对真实 versionCode、descriptor、229/256
模式结构和系统输入事件。不要仅凭底包相似扩大版本门，也不要把本次关闭的逐事件诊断日志
重新带入正式版。
