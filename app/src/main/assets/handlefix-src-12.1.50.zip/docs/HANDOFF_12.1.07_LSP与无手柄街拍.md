# 12.1.07：LSPosed 启用检测与 Phoenix 无手柄街拍

当前目标：
基于已验收的 12.1.06 增加模块启动检测、修复 Phoenix 0.8.0 街拍版本门、增加无手柄选项；本轮只构建和推送仓库，不安装或重启手机。

已经确认的事实：
- 2026-09-03 07:13:19.816，相机 760000800 加载时 promFix=true、streetSpecial=true；07:13:19.849 显示 StreetSpecial skip profile=none。根因是旧精确 760000300 门，尚未走到能力 Hook。
- 0.3.0 与 0.8.0 原始 DEX 共同包含 Je.c.M()Z、com.android.camera.data.data.w.d()Z、EquipStreetModuleEntry.getModuleId()I/support()Z；入口返回 229，模块继承 StreetModule/Camera2Module。w.d 仍读取 pref_camera_handle_equip_street，不能替换成常量。
- 两包 p6.b.g(Ljava/util/ArrayList;[Ljava/lang/Class;)V 创建 W5.b，读取 is_bluetooth_photography_handle 和 bluetooth_photography_handle_color；W5.b.Mg()Z 返回有线或蓝牙手柄状态。原生设置、模式路由和拍摄链不需要重写。
- 相机增强报告的全局 settings put + 广播方案存在持久化副作用；本实现只在相机进程的上述工厂调用范围内改读值，无全局写入、无广播、无新公共文件。真实手柄广播不被拦截，插拔后必要时重新打开相机。
- 官方 libxposed service 102.0.0 是设置 App 通信库，不是传统 Hook API 升级。API-82 与 xposed_init 保留。早到 Binder 由官方 Helper 缓存；Monitor 在 IO 线程读取框架名称/版本/API，死亡回调清除状态。只接受本应用 UID/root/system 的 SendBinder，验证接口描述符后转交官方 Provider。
- 主界面约 2 秒等待并再次读取状态，未确认时提供重新检测/退出，无忽略按钮。无服务也可能是不支持此服务的旧框架，不能断言未启用。成功也不证明相机/system_server 的作用域与 Hook 全部成功。

已经修改的文件：
- activation/：Application、受控 Provider 和单一连接 Monitor；ui/LspActivationGate.kt 阻止 Root/重启弹窗与启用提示叠加。
- StreetSpecialProfile.java/StreetSpecialHooks.java：Phoenix OS4 版本族作为候选，精确签名、返回类型、静态性、229 类结构共同校验后仅解锁 M；229 配置别名在成功安装后启用。不恢复曾引起 ClassCastException 的其它菜单 Hook。
- StreetSpecialWithoutGripHooks.java：ThreadLocal 构造范围，精确 getInt/getString 方法与两个键；失败回滚已装的子 Hook，不影响基础解锁。
- ModeConfig/MainActivity：父子依赖、默认关闭、保存失败不改 UI、导入清洗、恢复默认、文案与选项。
- Manifest/Gradle/R8、README、ModuleTexts、当前内置源码。

已经完成的验证：
- 手机仅作只读日志获取，版本 Phoenix 0.8.0；原始 APK DEX 描述符脚本已同时核对两包。
- 原生工厂与入口用定向 JADX 输出复核；全量 JADX 有非目标方法错误且 Windows 大小写目录存在碰撞，因此短名以原始 DEX 为准。
- JDK 21 的完整 :app:assembleRelease 已通过（含 Lint Vital、R8 和资源压缩）；合并 Manifest 中 Provider authority 为 com.handlefix.all.XposedService，传统 min API 82 与 xposed_init 保留。
- 最终 APK 签名与内置源码逐文件一致性由交付核验；不能用构建通过替代实机启用检测与无手柄验收。

仍然存在的问题：
- 新版本本轮未安装；Binder 实际投递、未启用/延迟/重连弹窗及 0.3.0/0.8.0 无手柄街拍需要实测。
- 不提供服务的旧 LSPosed 分支可能无法通过启动门禁；不使用 MODE_WORLD_READABLE 异常探针兜底。

下一步具体动作：
用户安装后先确认启用模块可进主页；再验证关闭模块时提示、重新启用与重试；在两版 Phoenix 开启父子选项和原生街拍设置，不插手柄进入街拍，退出/关闭开关后恢复普通街拍。实机若失败只抓时间窗口内的 StreetSpecial 和相机原生状态日志。

不能改变的约束：
不动已验收的 C3/长按连拍控制器，不新增 256 徕卡一瞬，不全局伪造 USB 手柄，不写系统设置、不发送伪造按键；正式包全局 Debug 关闭，保留环境检查与模块诊断。新版本只按共同结构放行，缺失/类型不匹配时停止安装并留下基础失败日志。
