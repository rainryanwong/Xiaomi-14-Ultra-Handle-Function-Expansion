# 12.1.08 传统模块启用检测修复

目标：消除 12.1.07 的无限等待，保持 API82 / 既有作用域及相机功能不变。

根因：手机 LSPosed7854 不向传统模块投递现代 XposedService。12.1.07 把现代 Binder 作为硬门禁且把 OverlayDialog 放在 Scaffold 外，导致无服务时提示也不能显示。

系统初始化签名必须按真实 services.jar 核对：本机 OS4 的 public init 为 (Context,WindowManagerFuncs,IWindowManager)V，另有 init(Injector)V。不能照搬旧平台的 (Context,IWindowManager,WindowManagerFuncs)V 参数顺序。仅精确匹配这两种带 Context 的描述符，不挂载全部 init 重载。

实现：删除不适用的 service102 依赖、Provider、Application 和 R8 规则。独立 ActivationProbeHooks 在 PhoneWindowManager.init(Context,IWindowManager,WindowManagerFuncs)V 或相机 Application.attach(Context)V 完成后注册只读运行时接收器，不改任何返回值。App 发显式包广播和 ResultReceiver，签名权限限制发送者；随机 nonce、精确 BuildConfig.VERSION_CODE 和 generation/cancellation 限制防止上次启动/旧包/重复响应被接受。无需修改作用域、读取框架数据库、Root 请求、磁盘缓存或启动相机。只证明已有作用域中至少一个进程实时加载当前包，不证明所有功能正常，也不能即时反映尚未重启进程的管理器开关变更。

UI：检测中/已确认/未确认三态。等待分支自带 Miuix Scaffold；最多等待 2 秒后显示未确认提示，可重试或继续设置。继续设置不会把状态伪造为 ACTIVE。返回键退出。重试/恢复前台不以 status 为 Effect key，避免状态变化重启超时循环。

约束：不动已验收连拍、C3、EV、半按对焦及无手柄街拍实现。本轮用户要求更新源码、安装和重启，不推送 GitHub。不把生产诊断开成逐事件 Debug。

验证：构建、签名、源码一致性和手机重启后实际探测响应须分别核验；未收到响应的 UI 与非当前版本响应拒绝不等同于实机禁用/重启全矩阵，不能声称全部场景验收。
