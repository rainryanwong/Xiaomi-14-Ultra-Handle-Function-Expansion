# HandleFix 12.1.49：相机模式快捷跳转

## 发布范围

- 新增二级页“相机模式快捷跳转”，统一收纳相机外长按录像键和长拨变焦拨杆。
- 长按录像键继续使用系统层 `VIDEO_CAMERA` 协议；相机已经在前台时不接管，由当前模式的录像键配置优先处理。
- 长拨变焦拨杆允许为左右方向分别指定目标模式，运行时只接管已识别 N1G 手柄、已配置方向、相机非前台且当前相机属于 Phoenix OS4 版本组的事务。
- 锁屏/息屏时使用小米相机自己的 `StartActivityWhenLocked` / `ShowCameraWhenLocked` 语义，不绕过 Keyguard。`GripInputGuard` 始终先执行；用户启用对应场景和变焦拨杆屏蔽后，快捷启动不会触发。

## 临时发布门限

主页入口只在以下两个条件同时满足时可点击：

1. 手柄按键映射方案为 Prometheus Cam（`promFix=true`）；
2. 当前 `com.android.camera` 的 `versionCode` 属于 `CameraBuilds.isPhoenixOs4Family()`。

其它组合保留入口但由 `ArrowPreference(enabled=false)` 原生置灰，不删除已保存配置。后续适配官方 OS3/OS4、NRV 或 V5.1 测试包时，应先补齐各相机族的目标模式解析器和能力表，再移除 `MainActivity.kt` 中的 `quickLaunchAvailable` 临时 UI 门限；不能只去掉门限而复用 Phoenix 的精确路由 Hook。

## 根因边界

- system_server 的 `GripQuickLaunchController` 只负责手柄事务、阈值、前台判断和发送带私有一次性目标的相机 Intent。
- 相机进程的 `PhoenixQuickLaunchHooks` 只在 Phoenix 描述符预检通过后安装，并只处理带 HandleFix 私有 launch source 的一次启动窗口。
- 普通街拍 225、街拍特别款 229 与街拍传奇款 229 的差异不写入 Phoenix 持久设置；传奇款只为本次启动选择 `FragmentEquipStreetNew`。
- 逐事务成功日志走 `VERBOSE_HOOK_LOG`，正式版保持关闭；安装失败、启动失败和反射异常仍保留日志。

## 验证边界

- Phoenix 冷/热启动、左右方向、十个主模式、225/229 强制路由和传奇款 UI 已在 12.1.49 测试序列中实机验收。
- 本次新增的锁屏/息屏放行已完成静态调用顺序和构建验证；正式包发布时不把它描述为已完成实机验收。若后续复测，至少覆盖输入保护关闭、仅锁屏、仅息屏、两者，以及相机原本位于前台后息屏的场景。
