当前目标：
发布12.1.12/1315，整合12.1.10和12.1.11界面调整及修复，用户自行安装。

已经确认的事实：
Miuix OverlayDialog必须在Scaffold提供的弹窗宿主内部调用。机型拦截、开发者确认均遵守此结构，不能作为Scaffold的兄弟节点。机型确认使用与建议重启相同的DialogButtons蓝色主按钮，点击退出。
机型按Build.MODEL/DEVICE/PRODUCT独立匹配；aurora、24031PN0DC、Xiaomi14Ultra/小米14Ultra任一符合即可。没有新增系统大版本门限。
模块诊断统一入口，页签为环境检查和模块诊断；开发者/显示模式编号共用开关。主题themeMode=0/1/2对应系统/浅色/深色，保存在现有JSON并随备份恢复。
报告保存采用MediaStore，位置Download/HandleFixConfig/Reports；Root只用于既有环境信息采集。原偶现失败未保留具体异常，不声称已证实历史根因。新写入路径记录异常并删除本次失败的pending行。

已经修改的文件：
MainActivity、EnvCheckActivity、HookProbeActivity、ModuleDiagnosticsScreen、DeviceEligibilityGate、DiagnosticReportExport、Theme、SystemUi、ImportBackupActivity、ModeConfig、Manifest、Gradle、ModuleTexts及本版本源码ZIP。

已经完成的验证：
12.1.10/11测试包JDK21普通release构建及签名通过；已读取两台手机的型号、版本和窄日志。最终发布包另做构建、签名及源码逐文件一致性校验，结果见STATUS。

仍然存在的问题：
不将构建成功代替用户实机验收；新蓝色按钮、主题和报告路径由用户安装最终包检查。已有设备信息可被移植ROM改写，不属于硬件认证。

下一步具体动作：
安装12.1.12，核对非支持机型确认退出、开发者确认保存、双页签返回及三种主题、报告导出。

不能改变的约束：
不恢复LSPosed每次onResume重建主页的旧逻辑。相机Hook未改；不新增系统大版本检测。用户自行安装，不推送/重启手机。内置源码必须与发布工作树匹配。
