# v12.1.24 滤镜选择与开发者过滤简报

当前目标：
发布 v12.1.24，在 Phoenix OS4 版本组与官方相机 6.6.000510.0 首批提供录像键短按“滤镜选择”，并把超清 175 调整为常用映射模式。

已经确认的事实：
Phoenix-0.8.0 与官方 6.6.000510.0 已分别实测拍照、录像、专业拍照、专业录像、人像、街拍和超清。录像键可打开滤镜面板，拨轮可原生切换，再次短按可保持当前滤镜并关闭列表与分类栏；街拍特别款 229 继承普通街拍 225 配置。Prometheus Cam 强制启用的另一套 UI 与官方 UI 不同，相同底包不代表可直接复用 UI 描述符。

已经修改的文件：
NativeFilterPanelHooks 集中原生面板事务；OemHooks 与 PhoenixClassicStyleHooks 只负责把录像键松键转发给该控制器；ModeConfig 增加独立 Q 功能码与街拍特别款配置别名；KeyConfigActivity 增加超清过滤表、滤镜选项和统一开发者显示规则；ModuleTexts、README、版本号及内置源码同步更新。

已经完成的验证：
实机测试证明关闭链使用当前 Q6.j 宿主的原生 dr(false)/er() 卸载流程后，不再跳转录像、不改变当前滤镜，也不残留“滤镜/肖像风格”分类栏。正式包关闭全局 VERBOSE_HOOK_LOG 和滤镜窄诊断开关。

仍然存在的问题：
NRV 系列、V5.1 与 OS3 官方相机尚未反查和实测滤镜面板入口，正式版不对这些相机族宣称支持。开发者模式可以显示并保存未适配组合，但运行时仍会安全回退。

下一步具体动作：
按 NRV、V5.1、OS3 官方相机分别确认真实按键入口、面板宿主、当前页类型和原生关闭流程；不得因为底包相似直接复制 OS4 UI 描述符。适配期间如需定位，可临时同时启用 HandleFixModule.VERBOSE_HOOK_LOG 与 NativeFilterPanelHooks.FILTER_DIAGNOSTICS。上述三类全部完成后，删除 NativeFilterPanelHooks 的 traceRecord、trace、identity 和 FILTER_DIAGNOSTICS，以及调用侧仅为滤镜定位保留的 traceRecord 调用。

不能改变的约束：
滤镜动作不写相机偏好、不模拟系统按键、不注入触摸、不缓存跨按键 UI 状态、不手工隐藏 View。开发者模式只解除设置页过滤，不解除运行时能力门。诊断代码在后续三类适配完成前保留，但正式构建必须关闭。
